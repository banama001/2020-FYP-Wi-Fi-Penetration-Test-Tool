
#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule 


def aplessdef():
            def aplessstart():
                    delinktxtopen1=open("aplessruntxt.txt","r")
                    read= delinktxtopen1.read()
                    print(read)
                    tvlist=read.split("\n")
                    en=tvlist[0]
                    #en=" airbase-ng -c "+ airCH+" -a "+bssid+' -e "' + ESSID + '" -W 1 -z 2 -F apless '+ air_tar
                    print (en)
                    
                    
                    saveapless_txt=open("apless.txt",'w+')
                    p = subprocess.Popen(en,shell=True ,stdout=saveapless_txt, stderr=subprocess.STDOUT, preexec_fn=os.setsid)
                    

                    global aploop_num
                    aploop_num=0
                    global aplesslist
                    aplesslist=[]

                    
                    while aploop_num==0:
                        shutil.copyfile('apless.txt','aplessout.txt')
                        aplessout=open("aplessout.txt",'r')
                        for n in aplessout:
                            print( n)
                            if 'associated' in n:
                                print ('success')
                                aplessfalagopen=open("aplessfalag.txt","w+")
                                aplessfalagopen.write("aaa")
                                aplessfalagopen.close()
                                aploop_num=aploop_num+10    
                        
                      #the real code does filtering here
 
            thread_3 = threading.Thread(target=aplessstart())
            print ("start 2")
                    
            print ("start 1.1")
            thread_3.start() # start T2
             # join for T2
os.system("airmon-ng start wlan0")
aplessdef()           
