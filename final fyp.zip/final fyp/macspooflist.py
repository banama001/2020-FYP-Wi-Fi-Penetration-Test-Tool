
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import apless

from threading import Timer
global target

def makelist():
        aplesslist=open('viewtreemaclist.txt',"r+")
        viewtreeaplesscompare=open('connectbomdelink.txt',"r")
        apread= viewtreeaplesscompare.read()
        aplist1=apread.split("\n")

        aaa=open('macvtconnectedbom.txt',"r")
        apread1= aaa.read()
        aplist3=apread1.split("\n")


        
        for n in aplist1:
            aplesslist=open('viewtreemaclist.txt',"r")
            addaplesslist=open('viewtreemaclist.txt',"a+")
            
            global addapp
            addapp=0
            
            bssid=n[20:39]
            print(bssid)
            apreadorg= aplesslist.read()
            
            aplist2=apreadorg.split("\n")
            for a in aplist2:
                    
                if bssid in a:
                        print('same aplesslist not added')
                             
                        addapp=1
                        print(addapp)
            print(addapp)
            if addapp==0:
                        
                
                        print("added the new record of apless")
                        addaplesslist.write(n)
                        addaplesslist.write("\n")
                        addaplesslist.close()
            
            addaplesslist.close()

        for n in aplist3:
            global addapp1
            
            print("aplist3")
            aplesslist=open('viewtreemaclist.txt',"r")
            addaplesslist=open('viewtreemaclist.txt',"a+")
            
            addapp1=0
            
            bssid=n[20:39]
            print(bssid)
            apreadorg= aplesslist.read()
            
            aplist2=apreadorg.split("\n")
            for a in aplist2:
                    
                if bssid in a:
                        print('same aplesslist not added')
                             
                        addapp1=1
                        print(addapp)
            print(addapp1)
            if addapp1==0:
                        
                
                        print("added the new record of apless")
                        addaplesslist.write(n)
                        addaplesslist.write("\n")
                        addaplesslist.close()
            
            addaplesslist.close()


