#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import apless

import macspooflist


global target
open1=open("/root/Documents/data/selected.txt","r+")
open1=open1.read()
open1split=open1.split("\n")
for line in open1split:
    global target
    if "wlan" in line:
        global target
        target=line[0:5]
        print("scanning")
        print(target)






def aaa():
    global target
    print("->"+target)
    macspoof=open("macchanger.txt","r")
    read=macspoof.read()
    macsppfgo=read.split("\n")
    macspoofrun=macsppfgo[0]
    os.system("airmon-ng start "+target)
    
    os.system("ip link set dev "+target+"mon down")
    os.system(macspoofrun)
    os.system("ip link set dev "+target+"mon up")
    os.system("ip link show "+target)
    aplessfalagopen=open("macchangerfalag.txt","w+")
    aplessfalagopen.write("aaa")
    aplessfalagopen.close()
    os.system("ip link show wlan0mon")

    
    
aaa()
