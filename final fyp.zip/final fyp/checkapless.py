
open1=open("viewtreeapless.txt","rb")
                      

read= open1.read()
vlist1=read.decode().split("\n")

for n in vlist1:
    ESSID=n[93:]
    aaa=" ".join(ESSID.split())
    print("  ~~~~~|"+aaa+"|~~~   ")
