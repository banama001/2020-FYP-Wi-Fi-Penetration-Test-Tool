
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import time
import configparser
import signal
import threading
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule 


opem="gedit /etc/hostapd-wpe/hostapd-wpe.conf"
aa=os.system("ps -C hostapd-wpe > enteroutput.txt")
zz=open("enteroutput.txt","r")
enterread=zz.read()
enterread1=enterread.split("\n")
print(enterread1[1])
end=enterread1[1].find(" ")
print(end)
stre=str(enterread1[1])
enterread2=stre[1:6]
print(enterread2)
#enterread3=enterread2[1].split(" ")
#enterread3[0]
#os.system("kill -2 "+enterread2)

