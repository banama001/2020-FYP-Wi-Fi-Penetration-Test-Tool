
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import gif
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename

from tkinter import *
from tkinter.ttk import *
import schedule
from threading import Timer


main=tk.Tk()
main.title("introdution")


tabControl = ttk.Notebook(main)          # Create Tab Control
 
tab1 = ttk.Frame(tabControl)#0           # Create a tab #0
tabControl.add(tab1, text='De-link')

tab2 = ttk.Frame(tabControl)#0           # Create a tab #0
tabControl.add(tab2, text='AP-Less')

tab3 = ttk.Frame(tabControl)#0           # Create a tab #0
tabControl.add(tab3, text='Mac-spoofing')

tab4 = ttk.Frame(tabControl)#0           # Create a tab #0
tabControl.add(tab4, text='aaaa')

tabControl.pack(expand=1, fill="both")
global delinkvalid
delinkvalid=0
##############################################
tabee = ttk.Notebook(tab4)

ca = ttk.Frame(tabee)#0           # Create a tab #0
tabee.add(ca, text='aaaa')

tabee.pack(expand=1, fill="both")
        


introwlanlabel = ttk.Label(introdelink, text='How to use De-link ', font=("Helvetica", 20))
introwlanlabel.grid(column=0, row=1, padx=1, pady=1)

introlbl = gif.ImageLabel(introdelink)
introlbl.grid(column=0, row=2, padx=8, pady=4)
introlbl.load('delink3.gif')

def hidebuttondelink():
    global delinkvalid
    if delinkvalid==0:
        introlbl.grid_forget()
        delinkintro2.grid(column=0, row=2, padx=1, pady=1)
        delinkintro.grid(column=0, row=1, padx=1, pady=1)
        delinkintro3.grid(column=0, row=3, padx=1, pady=1)
        
        delinkvalid=delinkvalid+1
    else:
        introlbl.grid()
        delinkintro2.grid_forget()
        delinkintro3.grid_forget()
        delinkintro.grid_forget()
        delinkvalid=delinkvalid-1

introdelinkbutton = ttk.Button(introdelink, text='show on text' ,command=lambda: hidebuttondelink())
introdelinkbutton.grid(column=0, row=0, padx=1, pady=1)

delinkintro = ttk.Label(introdelink, text='1.click De-link button', font=("Helvetica", 20))
delinkintro2 = ttk.Label(introdelink, text='2.select the AP and station on bottom table.', font=("Helvetica", 20))
delinkintro3 = ttk.Label(introdelink, text='3.doubleclick the selected bar for Deauthentication attack', font=("Helvetica", 20))


################################





aplessgif = gif.ImageLabel(introapless)
aplessgif.grid(column=0, row=2, padx=8, pady=4)
aplessgif.load('apless2.gif')

global aplessvalid
aplessvalid = 0
def hidebuttonapless():
    global aplessvalid
    if aplessvalid==0:
        aplessgif.grid_forget()
        aplessintro.grid(column=0, row=1, padx=1, pady=1)
        aplessintro1.grid(column=0, row=2, padx=1, pady=1)
        aplessintro2.grid(column=0, row=3, padx=1, pady=1)
        
        aplessvalid=aplessvalid+1
    else:
        aplessgif.grid()
        aplessintro.grid_forget()
        aplessintro1.grid_forget()
        aplessintro2.grid_forget()
        aplessvalid=aplessvalid-1

introaplessbutton = ttk.Button(introapless, text='show on text' ,command=lambda: hidebuttonapless())
introaplessbutton.grid(column=0, row=0, padx=1, pady=1)


introaplesslabel = ttk.Label(introapless, text='How to use AP-less', font=("Helvetica", 20))
introaplesslabel.grid(column=0, row=1, padx=1, pady=1)

aplessintro = ttk.Label(introapless, text='1.click AP-Less button', font=("Helvetica", 20))
aplessintro1 = ttk.Label(introapless, text='2.select the target AP on table.', font=("Helvetica", 20))
aplessintro2 = ttk.Label(introapless, text='3.doubleclick the selected bar for AP-Less attack', font=("Helvetica", 20))




################################################################################################


macspoofgif = gif.ImageLabel(tab3)
macspoofgif.grid(column=0, row=2, padx=8, pady=4)
macspoofgif.load('macspoofing.gif')

global macvalid
macvalid=0
def hidebuttonmacspoofgif():
    global macvalid
    if macvalid==0:
        macspoofgif.grid_forget()
        macintro.grid(column=0, row=1, padx=1, pady=1)
        macintro1.grid(column=0, row=2, padx=1, pady=1)
        macintro2.grid(column=0, row=3, padx=1, pady=1)
        
        macvalid=macvalid+1
    else:
        aplessgif.grid()
        macintro.grid_forget()
        macintro1.grid_forget()
        macintro2.grid_forget()
        macvalid=macvalid-1

macbutton = ttk.Button(tab3, text='show on text' ,command=lambda: hidebuttonmacspoofgif())
macbutton.grid(column=0, row=0, padx=1, pady=1)


macspooflabel = ttk.Label(tab3, text='How to use MAC-spoofing', font=("Helvetica", 20))
macspooflabel.grid(column=0, row=1, padx=1, pady=1)

macintro = ttk.Label(tab3, text='1.click De-link button', font=("Helvetica", 20))
macintro1 = ttk.Label(tab3, text='2.select the target AP on top table .', font=("Helvetica", 20))
macintro2 = ttk.Label(tab3, text='1.doubleclick the selected bar for mac-address spoffing', font=("Helvetica", 20))

#########################################################################



















