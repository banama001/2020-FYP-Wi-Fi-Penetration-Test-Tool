
import time
import sys
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import toolTip
import wifiadpater as fypad
import subprocess
import os
import subprocess
from tkinter import messagebox


global target
open1=open("/root/Documents/data/selected.txt","r+")
open1=open1.read()
open1split=open1.split("\n")
for line in open1split:
    if "wlan" in line:
        target=line[0:6]
        print("scanning")
        print(target)



def scanningstart():
    b='airmon-ng check kill all'
    os.system(b)
    print("done airmon-ng check kill all")   
    start='sudo airmon-ng start '+target
    os.system(start)
    print(start)
    #os.system("killall -e airodump-ng")
    airmonngstart='sudo airodump-ng '+target+"mon "
    print(airmonngstart)
    airmonngstarttxt=open("scanning.txt","w+")
    
    p=subprocess.Popen(airmonngstart,shell=True ,stdout=subprocess.PIPE ,stderr=subprocess.STDOUT, preexec_fn=os.setsid)

    global loop_num
    loop_num=0
    while True:
          line = p.stdout.readline()

          if loop_num>1000:
            break
          #the real code does filtering here
          
          airmonngstarttxt.write(line.decode().rstrip())
          airmonngstarttxt.write("\n")
          loop_num =loop_num+1
    p.kill()

    
    







#-----------------有連接driver既network----------------------#

def vtconnectedtop():
            
            open1=open("scanning.txt","rb")
            read= open1.read()
            global sc_list4
            sc_list4=read.decode().split("\n")
            print(sc_list4)
            global sc_list3
            sc_list3=[]
            for n in sc_list2:
                print(n)
                ta=n[0:18]
                print (ta )
                for a in sc_list4:         
                    if ta in str(a) :
                        sc_list3.append(a)
                        break
            
            
            global showall_count
            showall_count=4
            global showall_label
            sc_list3.sort()
            
            save_txt=open("vtconnectedtop.txt","w+")
            for n in sc_list3:
                
                save_txt.write(n)
                save_txt.write("\n")
                
def vtconnectedbom():
            open1=open("scanning.txt","rb")
            read= open1.read()
            global sc_list4
            sc_list4=read.decode().split("\n")
            global sc_list3
            sc_list3=[]
            for n in sc_list2:
                print (n)
                ta=n[0:37]
                print(ta )
                for a in sc_list4:         
                    if ta in str(a) :
                        sc_list3.append(a)
                        break
            
            
            global showall_count
            showall_count=4
            global showall_label
            sc_list3.sort()
            
            save_txt=open("vtconnectedbom.txt","w+")
            for n in sc_list3:
                
                save_txt.write(n)
                save_txt.write("\n")
        

def vtbomscan():
            
            open1=open("scanning.txt","rb")
            read= open1.read()

            zxc=read.decode().split(" BSSID              PWR  Beacons    #Data, #/s  CH  MB   ENC  CIPHER AUTH ESSID")
            print (zxc)
            qwe=read.decode().split("\n")
            print(qwe)
            global list1
            list1=[]
            #find the 11:11:11:11 in txt
            format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}\s+\w{2}:\w{2}:\w{2}:\w{2}')
            format2=re.compile('.\W')
            for n in qwe:
                a=str(n)
                if re.match(format2,a)!=None:
                        print(".")
                elif re.findall(format1,a):
                        list1.append(n)


            list1=list(dict.fromkeys(list1))
             #remove the (not associated) in list1
            
            for n in list1:
                a=" (not associated)  "     
                if a in n:
                   
                    list1.remove(n)
            save_txt=open("vtbom1.txt","w+")
            for n in list1:
                
                save_txt.write(n)
                save_txt.write("\n")
            
            


            global sc_list2
            sc_list2 =[]

            for n in list1:
                    a=n[0:37]
                    sc_list2.append(a)
            sc_list2=list(dict.fromkeys(sc_list2))
            

                
            save_txt=open("vtbom2.txt","w+")
            for n in sc_list2:
                print (n)
                save_txt.write(n)
                save_txt.write("\n")
            vtconnectedtop()
            vtconnectedbom()

        



#--------------------所有network--------------------#

def vttopfli():
            
            open1=open("scanning.txt","rb")
            read= open1.read()
            global sc_list4
            sc_list4=read.decode().split("\n")
            print(sc_list4)
            global sc_list3
            sc_list3=[]
            for n in sc_list2:
                print( n)
                ta=n[0:18]
                print( ta )
                for a in sc_list4:         
                    if ta in str(a) :
                        sc_list3.append(a)
                        break
            
            
            global showall_count
            showall_count=4
            global showall_label
            sc_list3.sort()
            
            save_txt=open("viewtree.txt","w+")
            for n in sc_list3:
                
                save_txt.write(n)
                save_txt.write("\n")
        
        

def vttopallscan():
            
            open1=open("scanning.txt","rb")
            read= open1.read()

            zxc=read.decode().split(" BSSID              PWR  Beacons    #Data, #/s  CH  MB   ENC  CIPHER AUTH ESSID")
            qwe=read.decode().split("\n")
            global list1
            list1=[]
            #find the 11:11:11:11 in txt
            format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}')
            format2=re.compile('.\W')
            for n in qwe:
                a=str(n)
                if re.match(format2,a)!=None:
                        print(".")
                elif re.findall(format1,a):
                        list1.append(n)


            list1=list(dict.fromkeys(list1))
             #remove the (not associated) in list1
            
            for n in list1:
                a=" (not associated)  "     
                if a in n:
                   
                    list1.remove(n)
            save_txt=open("viewtree1.txt","w+")
            for n in list1:
                
                save_txt.write(n)
                save_txt.write("\n")
            
            


            global sc_list2
            sc_list2 =[]

            for n in list1:
                    a=n[0:19]
                    sc_list2.append(a)
            sc_list2=list(dict.fromkeys(sc_list2))
            

                
            save_txt=open("viewtree2.txt","w+")
            for n in sc_list2:
                print (n)
                save_txt.write(n)
                save_txt.write("\n")
            vttopfli()

        
def getall():
        
        scanningstart()
        vttopallscan()
        vtbomscan()



  
           

   
