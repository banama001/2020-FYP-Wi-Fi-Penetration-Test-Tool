import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading

import shlex
import time
import configparser
import signal
import threading

import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename

from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
class ImageLabel(tk.Label): 
                """a label that displays images, and plays them if they are gifs""" 
                def load(self, im): 
                 if isinstance(im, str): 
                  im = Image.open(im) 
                 self.loc = 0 
                 self.frames = [] 

                 try: 
                  for i in count(1): 
                   self.frames.append(ImageTk.PhotoImage(im.copy())) 
                   im.seek(i) 
                 except EOFError: 
                  pass 

                 try: 
                  self.delay = im.info['duration'] 
                 except: 
                  self.delay = 100 

                 if len(self.frames) == 1: 
                  self.config(image=self.frames[0]) 
                 else: 
                  self.next_frame() 

                def unload(self): 
                 self.config(image=None) 
                 self.frames = None 

                def next_frame(self): 
                 if self.frames: 
                  self.loc += 1 
                  self.loc %= len(self.frames) 
                  self.config(image=self.frames[self.loc]) 
                  self.after(self.delay, self.next_frame)
                
