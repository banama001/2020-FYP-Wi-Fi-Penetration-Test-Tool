
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import apless
import csv

import pandas as pd
from threading import Timer
global target


def aa():
                open1=open("viewtreemaclist.txt","r")
                read= open1.read()
                sc_list2=read.split("\n")
                
                check=open("macmix.txt","r")
                apreadorg= check.read()  
                aplist2=apreadorg.split("\n")
                print(sc_list2)
                for n in sc_list2:
                    global flag
                    flag=0
                    write=open("macmix.txt","a+")
                    format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}')
                    a=str(n)
                        
                    bssid=n[3:23]
        
                    if re.findall(format1,a):#check is it xx:xx:xx:xx:xx
                        
                        for aa in aplist2:
                            #print('...')
                            #print(aa)
                            #print('...')
                            if bssid in str(aa):
                                print('same bssidclient not added')
                            else:
                                #print('added')
                                flag=1
                    else:
                        print("not match")
                                
                               
                    if flag==1:
                        write.write(str(n))
                        write.write("\n")
                        write.close()

aa()
