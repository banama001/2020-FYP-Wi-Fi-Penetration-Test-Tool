#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename

from tkinter import *
from tkinter.ttk import *
import schedule 



def clientless():
            def clientlessstart():
                    #delinktxtopen1=open("clientlessruntxt.txt","r")
                    #read= delinktxtopen1.read()
                    #print(read)
                    #tvlist=read.split("\n")
                    #en=tvlist[0]
                    #en=" airbase-ng -c "+ airCH+" -a "+bssid+' -e "' + ESSID + '" -W 1 -z 2 -F apless '+ air_tar
                    #print (en)
                    
                    
                    saveapless_txt=open("clientless.txt",'w+')
                    en="cd /root/clientlessinstalltool/hcxdumptool && ./hcxdumptool -o hash -i wlan0mon --filterlist=filter.txt --filtermode=2 --enable_status=1 "
                    
                    p = subprocess.Popen(en,shell=True ,stdout=saveapless_txt, stderr=subprocess.STDOUT, preexec_fn=os.setsid)
                    print("asd")

                    global aploop_num
                    aploop_num=0
                    global aplesslist
                    aplesslist=[]

                    
                    while aploop_num==0:
                        shutil.copyfile('clientless.txt','clientlessout.txt')
                        aplessout=open("clientlessout.txt",'r')
                        for n in aplessout:
                            print(n)
                            if 'FOUND PMKID CLIENT-LESS' in n:
                                os.system("time date")
                                os.system("cd /root/clientlessinstalltool/hcxdumptool && cp hash /root/clientlessinstalltool/hcxtools/hash")
                                print ('success')
                                aplessfalagopen=open("clientfalag.txt","w+")
                                aplessfalagopen.write("aaa")
                                aplessfalagopen.close()
                                aploop_num=aploop_num+10    
                        
                      #the real code does filtering here
 
            thread_3 = threading.Thread(target=clientlessstart())
            print ("start 2")
                    
            print ("start 1.1")
            thread_3.start() # start T2
            thread_3.join()
            
                
                
            
            print("doneall")


clientless()
