#-------------#3--Tab8---------makepasswordlist------------------#


# verify input type and generate wordlist (Crunch)
def Combination():
        global SVaule, LVaule, NLS

        user_Sinput = SVaule.get()
        user_Linput = LVaule.get()
   
   
        user_Sinput = int(user_Sinput)
        user_Linput = int(user_Linput)
        
        os.system('crunch ' + SVaule.get() + ' ' + LVaule.get() + ' ' + NLS.get() + ' -o wordlist.txt')
        
        
        os.system("cp wordlist.txt /root/clientlessinstalltool/hashcat/wordlist.txt")
        finish =  tk.messagebox.showinfo("Finish", "Your Wordlist was Generated and start crack password")
        en1 = "cd /root/clientlessinstalltool/hcxtools && ./hcxpcaptool -z pass hash && cp pass /root/clientlessinstalltool/hashcat/pass "
        os.system(en1)
        # join for T2
        def laststep():
                en2 = " cd /root/clientlessinstalltool/hashcat && ./hashcat -m 16800 pass -a 0 'wordlist.txt' --force --show "
                savepassword_txt=open("clientlesspas.txt",'w+')
                p2 = subprocess.Popen(en2,shell=True ,stdout=savepassword_txt, stderr=subprocess.STDOUT, preexec_fn=os.setsid)

        thread5 = threading.Thread(target=laststep())
        print ("start 2")
                        
        print ("start 1.1")
        thread5.start() # start T2
        thread5.join()
        displaypassword=open("clientlesspas.txt",'r')
        clientlesspassword=displaypassword.read()
        clientlesspassword1=clientlesspassword.split("\n")
        clilentconfid=str(clientlesspassword1[0])
        global clientessid
        clientlesspassword1start=clientlesspassword1[0].find(str(clientessid))
        
        print(clientlesspassword[clientlesspassword1start:])
        clientlesspassword1end=clientlesspassword1start+len(clientessid)+1
        clientpasswordfinal=clilentconfid[clientlesspassword1end:]
        print(clientpasswordfinal)
        finish =  tk.messagebox.showinfo("Finish", "Your password is "+str(clientpasswordfinal))
        time.sleep(1)
        os.system("cd /root/clientlessinstalltool/hcxtools && rm pass && rm hash ")
        os.system("cd /root/clientlessinstalltool/hashcat && rm wordlist.txt && rm pass ")
        os.system("cd /root/Documents/gui && rm clientlesspas.txt ")

# input data needed for Crunch

global SVaule
global LVaule
global NLS
Range = ttk.Label(makepaslist, text = 'Input range: ', font=("Helvetica", 20))
Range.grid(column=1, row=0, padx=8, pady=4)
Smallest = ttk.Label(makepaslist, text = 'Smallest: ', font=("Helvetica", 20))
Smallest.grid(column=1, row=1, padx=8, pady=4)
SVaule = ttk.Entry(makepaslist, width=5, font=("Helvetica", 20))
SVaule.grid(column=2, row=1, padx=8, pady=4)
Largest = ttk.Label(makepaslist, text = 'Largest: ', font=("Helvetica", 20))
Largest.grid(column=4, row=1, padx=8, pady=4)
LVaule = ttk.Entry(makepaslist, width=5, font=("Helvetica", 20))
LVaule.grid(column=5, row=1, padx=8, pady=4)
Include = ttk.Label(makepaslist, text = 'Characters include: ', font=("Helvetica", 20))
Include.grid(column=1, row=3, padx=8, pady=4)
NLS = ttk.Entry(makepaslist, width=37, font=("Helvetica", 20))
NLS.grid(column=2, row=3, padx=8, pady=4,columnspan=10)
Generate = ttk.Button(makepaslist, text ="Generate", command = Combination)
Generate.grid(column=1, row=5, padx=8, pady=4)
