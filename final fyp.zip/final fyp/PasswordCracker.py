import Tkinter
import os
import subprocess
import tkMessageBox
import thread
import datetime
import csv
import pandas as pd
from tkinter import filedialog
from Tkinter import *
from PIL import Image, ImageTk

global window, cap, success, Start, window2, txt, SVaule, LVaule, NLS, window3, window4, cap2, success2, Start2, Plength, NewList, window6, PassLen, Continue, FilterP, window7, cap3, success3, window8, txt3, Start3, output4, CrackTime, output3, output2

root = Tk()
root.title("Password Cracking Tools")
root.geometry("350x170")

option_a = IntVar()
option_b = IntVar()
option_c = IntVar()
option_d = IntVar()

# insert background image
canvas = Canvas(root, width=400, height=400)
image=ImageTk.PhotoImage(Image.open("open-locker.gif"))
canvas.create_image(0,0,anchor=NW, image=image)
canvas.place(x=50, y=-50)

# input .cap file name window (JTR)
def John():
   global window, cap

   window = Tkinter.Toplevel(root)
   FileName = Label(window, text = 'Input .cap file name: ', fg="blue")
   FileName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   cap = Entry(window, width=30, bd=5)
   cap.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Convert = Tkinter.Button(window, text ="Convert", command=convert)
   Convert.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify and convert file format for JTR
def convert():
   global window, cap, success, Start

   verify = ".cap"
   UserInput = cap.get()
   if verify in UserInput:
      os.system('aircrack-ng ' + cap.get() + ' -J john')
      os.system('hccap2john john.hccap > wpa')
      os.system('rm john.hccap')
      window.destroy()
      success = Label(root, text = 'Successfully convert the file for cracking', fg="blue")
      success.pack()
      Heading.destroy()
      JTR.destroy()
      SubHeading.destroy()
      Crunch.destroy()
      Hashcat.destroy()
      Change1.destroy()
      Filter.destroy()
      HC16800.destroy()
      Start = Tkinter.Button(root, text ="Start Cracking", command=wordlist)
      Start.place(x=120, y=70)
   else:
      Retype = Label(window, text = 'Wrong file format', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# input .txt file name window (JTR)
def wordlist():
   global window2, txt

   window2 = Tkinter.Toplevel(root)
   TxtName = Label(window2, text = 'Input wordlist name: ', fg="blue")
   TxtName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   txt = Entry(window2, width=30, bd=5)
   txt.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Crack = Tkinter.Button(window2, text ="Crack", command=result)
   Crack.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify file format, perform password cracking and show result (JTR)
def result():
   global window2, txt, success, Start, output4

   verify = ".txt"
   UserInput = txt.get()
   if verify in UserInput:
      os.system('john --wordlist=' + txt.get() + ' wpa')
      cmd = "john --show wpa"
      output4 = subprocess.check_output(cmd, shell=True)
      window2.destroy()
      Result = Label(root, text = 'Here is the result for password cracking:', fg="blue")
      Result.pack()
      success.destroy()
      Start.destroy()
      Textbox = Tkinter.Text(root, height=6, width=40)
      Textbox.pack()
      Textbox.insert(INSERT, output4)
      Report = Tkinter.Button(root, text ="Report & Exit", command=report)
      Report.place(x=120, y=135)
   else:
      Retype = Label(window2, text = 'Wrong file format', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# Generate report base on output (JTR)
def report():
   global output4
   
   f = open('JTRreport.txt', 'w')
   output4 = output4.split(':')

   for x in range(len(output4)):
      if x % 8 == 0:
         f.write('AP Name(ESSID): ' + output4[x] + '\n')
      if x % 8 == 1:
         f.write('Password: ' + output4[x] + '\n')
      if x % 8 == 2:
         f.write('Client MAC Address(BSSID): ' + output4[x] + '\n')
      if x % 8 == 3:
         f.write('AP MAC Address(BSSID): ' + output4[x] + '\n')
      if x % 8 == 6:
         f.write('Wireless Security Protocols: ' + output4[x] + '\n')
      if x % 8 == 7:
         f.write('Orginal file: ' + output4[x] + '\n')
   CrackTime = str(datetime.datetime.now())
   f.write('Time: ' + CrackTime)
   f.write('\n\nRecommendation for strong password:' + '\n' + '1. Must includes Numbers, Symbols, Capital Letters, and Lower-Case Letters' + '\n' + '2. The password length should not be lower than 12 characters' + '\n' + '3. Password should not be a dictionary word or combination of dictionary words')
   root.destroy()

# input .cap file name window (hashcat)
def hashcat():
   global window4, cap2

   window4 = Tkinter.Toplevel(root)
   FileName = Label(window4, text = 'Input .cap file name: ', fg="blue")
   FileName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   cap2 = Entry(window4, width=30, bd=5)
   cap2.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Convert = Tkinter.Button(window4, text ="Convert", command=hccapx)
   Convert.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify and convert file format for hashcat
def hccapx():
   global window4, cap2, success2, Start2

   verify = ".cap"
   UserInput = cap2.get()
   if verify in UserInput:
      os.system('cd')
      os.system('/usr/share/hashcat-utils/cap2hccapx.bin /root/Desktop/' + cap2.get() + ' /root/Desktop/wpa.hccapx')
      window4.destroy()
      success2 = Label(root, text = 'Successfully convert the file for cracking', fg="blue")
      success2.pack()
      Heading.destroy()
      JTR.destroy()
      Hashcat.destroy()
      HC16800.destroy()
      SubHeading.destroy()
      Crunch.destroy()
      Change1.destroy()
      Filter.destroy()
      Start2 = Tkinter.Button(root, text ="Start Cracking", command=hashlist)
      Start2.place(x=120, y=70)
   else:
      Retype = Label(window4, text = 'Wrong file format', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# input .txt file name window (hashcat)
def hashlist():
   global window5, txt2

   window5 = Tkinter.Toplevel(root)
   TxtName = Label(window5, text = 'Input wordlist name: ', fg="blue")
   TxtName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   txt2 = Entry(window5, width=30, bd=5)
   txt2.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Crack = Tkinter.Button(window5, text ="Crack", command=Output)
   Crack.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify file format, perform password cracking and show result (hashcat)
def Output():
   global window5, txt2, success2, Start2, output2
   verify = ".txt"
   UserInput = txt2.get()
   if verify in UserInput:
      os.system('hashcat -m 2500 -a 0 wpa.hccapx ' + txt2.get() + ' --force')
      cmd2 = "hashcat -m 2500 --show wpa.hccapx"
      output2 = subprocess.check_output(cmd2, shell=True)
      window5.destroy()
      Result = Label(root, text = 'Here is the result for password cracking:', fg="blue")
      Result.pack()
      success2.destroy()
      Start2.destroy()
      Textbox = Tkinter.Text(root, height=6, width=40)
      Textbox.pack()
      Textbox.insert(INSERT, output2)
      Report3 = Tkinter.Button(root, text ="Report & Exit", command=report3)
      Report3.place(x=120, y=135)
   else:
      Retype = Label(window5, text = 'Wrong file format', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# Generate report base on output (hashcat)
def report3():
   global output2
   
   f = open('HC2500report.txt', 'w')
   output2 = output2.replace(':', ' ')
   output2 = output2.replace('\n', ' ')
   output2 = output2.split()

   for x in range(len(output2)):
      if x % 5 == 0:
         f.write('Hash: ' + output2[x] + '\n')
      if x % 5 == 1:
         f.write('AP MAC address: ' + output2[x] + '\n')
      if x % 5 == 2:
         f.write('Client MAC address: ' + output2[x] + '\n')
      if x % 5 == 3:
         f.write('AP ESSID(Name): ' + output2[x] + '\n')
      if x % 5 == 4:
         f.write('Password: ' + output2[x] + '\n\n')
   CrackTime = str(datetime.datetime.now())
   f.write('Time: ' + CrackTime)

   window10 = Tkinter.Toplevel(root)
   window10.geometry("200x160")
   
   def convertToCsv2():
      read_file = pd.read_csv(r'/root/Desktop/HC2500report.txt')
      read_file.to_csv (r'/root/Desktop/HC2500report.csv', index = None)
      os.system('rm HC2500report.txt')

   ConvertCSV2 = Tkinter.Button(window10, text ="Convert Text to CSV", command=convertToCsv2, height = 1, width = 17)
   ConvertCSV2.place(x=18, y=25)

   def exit3():
      root.destroy()

   Exit3 = Tkinter.Button(window10, text ="Exit Application", height = 1, width = 17, command=exit3)
   Exit3.place(x=18, y=70)

# input data needed for Crunch
def Crunch():
   global SVaule, LVaule, NLS, window3

   window3 = Tkinter.Toplevel(root)
   window3.geometry("350x230")
   Range = Label(window3, text = 'Input range: ', fg="blue")
   Range.place(x=15, y=0)
   Smallest = Label(window3, text = 'Smallest: ', fg="green")
   Smallest.place(x=15, y=35)
   SVaule = Entry(window3, width=5, bd=5)
   SVaule.place(x=85, y=30)
   Largest = Label(window3, text = 'Largest: ', fg="green")
   Largest.place(x=180, y=35)
   LVaule = Entry(window3, width=5, bd=5)
   LVaule.place(x=240, y=30)
   Include = Label(window3, text = 'Characters include: ', fg="blue")
   Include.place(x=15, y=75)
   NLS = Entry(window3, width=37, bd=5)
   NLS.place(x=15, y=100)
   Generate = Tkinter.Button(window3, text ="Generate", command = Combination)
   Generate.place(x=133, y=170)

# verify input type and generate wordlist (Crunch)
def Combination():
   global SVaule, LVaule, NLS, window3

   user_Sinput = SVaule.get()
   user_Linput = LVaule.get()
   
   try:
      user_Sinput = int(user_Sinput)
      user_Linput = int(user_Linput)
      assert(user_Sinput > 0 and user_Linput > 0 and user_Sinput <= user_Linput)

      os.system('crunch ' + SVaule.get() + ' ' + LVaule.get() + ' ' + NLS.get() + ' -o wordlist.txt')
      window3.destroy()
      SubHeading.destroy()
      Crunch.destroy()
      Change1.destroy()
      Filter.destroy()
      finish = tkMessageBox.showinfo("Finish", "Your Wordlist was Generated")

   except Exception:
      Error = Label(window3, text = 'Wrong input, please input postive integer', fg="red")
      Error.place(x=15, y=132)
      Error2 = Label(window3, text = 'in Input range and Largest >= Smallest', fg="red")
      Error2.place(x=15, y=150)

# Enter the old password (Change1)
def Change1():
   global window5, Old

   window5 = Tkinter.Toplevel(root)
   FileName = Label(window5, text = 'Input old password: ', fg="blue")
   FileName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   Old = Entry(window5, width=30, bd=5)
   Old.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Convert = Tkinter.Button(window5, text ="Convert", command=DRI)
   Convert.grid(row=2, column=3, padx=5, pady=5, stick=S)

# Generate List Rules (Change1)
def DRI():
   global window5, Old, Plength, NewList
   
   f = open('password.txt', 'w')
   f.write(Old.get())
   
   Plength = len(Old.get()) 
   with open('/etc/john/john.conf') as g:
      if '[List.Rules:delete0]' in g.read():
         pass
      else:
         LR = open('/etc/john/john.conf', 'a')
         for x in range(Plength):
            LRDRI = '[List.Rules:delete' + str(x) +']\nD' + str(x) + '\n\n' + '[List.Rules:replace' + str(x) +']\nD' + str(x) + 'i' + str(x) + '[!-~]\n\n' + '[List.Rules:insert' + str(x) +']\ni' + str(x) + '[!-~]\n\n'
            LR.write(LRDRI)
         LRI = '[List.Rules:insert' + str(Plength) +']\ni' + str(Plength) + '[!-~]\n\n'
         LR.write(LRI)

   NewList = Tkinter.Button(root, text ="NewList", command=NewWordlist)
   NewList.place(x=130, y=105)
   window5.destroy()
   finish = tkMessageBox.showinfo("Finish", "Your List Rules was Generated")
   Change1.destroy()

# Generate Wordlist base on the rules (Change1)
def NewWordlist():
   global Plength, NewList, FilterP

   for x in range(Plength):
      os.system('john --wordlist=password.txt --stdout --rules:delete' + str(x) + ' > delete' + str(x) + '.txt')
      os.system('john --wordlist=password.txt --stdout --rules:replace' + str(x) + ' > replace' + str(x) + '.txt')
      os.system('john --wordlist=password.txt --stdout --rules:insert' + str(x) + ' > insert' + str(x) + '.txt')
   os.system('john --wordlist=password.txt --stdout --rules:insert' + str(Plength) + ' > insert' + str(Plength) + '.txt')

   string1 = str("cat ")

   for x in range(Plength):
      subx = str(x)
      substring = ("delete"+subx+".txt ")
      string1 = string1+ substring

   for x in range(Plength):
      subx = str(x)
      substring = ("replace"+subx+".txt " )
      string1 = string1+ substring

   for x in range(Plength+1):
      subx = str(x)
      substring = ("insert"+subx+".txt ")
      string1 = string1+ substring

   new = "> wordlist.txt"
   string1 = string1 + new
   os.system (string1)
 
   for x in range(Plength):
      os.system('rm delete' + str(x) + '.txt')
      os.system('rm replace' + str(x) + '.txt')

   for x in range(Plength + 1):
      os.system('rm insert' + str(x) + '.txt')

   finish = tkMessageBox.showinfo("Finish", "Your Wordlist was Generated")
   NewList.destroy()
   Crunch.destroy()
   Filter.destroy()
   SubHeading.destroy()

# input password length window (Filter)
def FilterPass():
   global window6, PassLen, FilterP

   window6 = Tkinter.Toplevel(root)
   Length = Label(window6, text = 'Input password length: ', fg="blue")
   Length.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   PassLen = Entry(window6, width=30, bd=5)
   PassLen.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   FilterP = Tkinter.Button(window6, text ="Generate", command=Brute)
   FilterP.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify input type and generate wordlist (Filter)
def Brute():
   global window6, PassLen, Continue

   user_Pinput = PassLen.get()
   
   try:
      user_Pinput = int(user_Pinput)
      assert(user_Pinput > 0)
      os.system('crunch ' + PassLen.get() + ' ' + PassLen.get() + ' -f /usr/share/rainbowcrack/charset.txt ascii-32-95  -o passlist.txt')
      window6.destroy()
      Filter.destroy()
      Continue = Tkinter.Button(root, text ="Continue", command=DeleteExtra)
      Continue.place(x=240, y=105)
   except Exception:
      Retype = Label(window6, text = 'It should be a postive integer', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# Checkbox for Wordlist Filtering(Filter)
def DeleteExtra():
   def DeleteExtra2(a,b,c,d):
      special = "!\"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~"
      numberic = "1234567890"
      loop = [False,False,False,False]
      f=open("passlist.txt", "r")
      f1=f.readlines()
      password = []
      check = []
    
      for x in f1:
         x = x.strip()
         password.append(x)
    
      if a == True:
         loop[0] = True
      if b == True:
         loop[1] = True
      if c == True:
         loop[2] = True
      if d == True:
         loop[3] = True
        
      diff = password
      for xx in range(len(loop)):
         if loop[xx] == True:
            for contents in diff:
               sub = ''

               for x in contents:
                  if xx == 0 and x.isupper():
                     sub += x
                  if xx == 1 and x.islower():
                     sub += x
                  if xx == 2 and x in numberic:
                     sub += x
                  if xx == 3 and x in special:
                     sub += x

               if len(sub) == 0:
                  check.append(contents)

               diff = list(set(password) - set(check))

      ff=open("passlist.txt", "w")
      for x in diff:
         ff.write(x)
         ff.write("\n")
      ff.close()

   choice = str(raw_input("1: Must Contain captial letter, 2: Must Contain small letter, 3: Must Contain Number, 4: Must Contain Special Number: ")).split()

   a = False
   b = False
   c = False
   d = False
   for x in choice:
      if x == "1":
         a = True
      if x == "2":
         b = True
      if x == "3":
         c = True
      if x == "4":
         d = True
      if not a and not b and not c and not d:
         print("Please retry, the input should between 1-4 with spacing.")
         DeleteExtra()

   DeleteExtra2(a,b,c,d)
   SubHeading.destroy()
   Crunch.destroy()
   Change1.destroy()
   Continue.destroy()

# Window for user to input PMKID file name (HC 16800)
def hc16800():
   global window7, cap3

   window7 = Tkinter.Toplevel(root)
   FileName = Label(window7, text = 'Input PMKID file name: ', fg="blue")
   FileName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   cap3 = Entry(window7, width=30, bd=5)
   cap3.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Convert = Tkinter.Button(window7, text ="Convert", command=hcxpcap)
   Convert.grid(row=2, column=3, padx=5, pady=5, stick=S)

# convert PMKID file to hashcat crackable format (HC 16800)
def hcxpcap():
   global window7, cap3, success3, Start3
   os.system('./hcxpcaptool -z pass ' + cap3.get())
   window7.destroy()
   success3 = Label(root, text = 'Successfully convert the file for cracking', fg="blue")
   success3.pack()
   Heading.destroy()
   JTR.destroy()
   Hashcat.destroy()
   HC16800.destroy()
   SubHeading.destroy()
   Crunch.destroy()
   Change1.destroy()
   Filter.destroy()
   Start3 = Tkinter.Button(root, text ="Start Cracking", command=M16800)
   Start3.place(x=120, y=70)

# input .txt file name window (HC 16800)
def M16800():
   global window8, txt3

   window8 = Tkinter.Toplevel(root)
   TxtName = Label(window8, text = 'Input wordlist name: ', fg="blue")
   TxtName.grid(row=0, column=0, padx=2, pady=5, sticky=W)
   txt3 = Entry(window8, width=30, bd=5)
   txt3.grid(row=0, column=1, columnspan=3, padx=5, pady=5)
   Crack = Tkinter.Button(window8, text ="Crack", command=hash16800)
   Crack.grid(row=2, column=3, padx=5, pady=5, stick=S)

# verify file format, perform password cracking and show result (HC 16800)
def hash16800():
   global window8, txt3, Start3, success3, output3
   verify = ".txt"
   UserInput = txt3.get()
   if verify in UserInput:
      os.system('hashcat -m 16800 pass -a 0 ' + txt3.get() + ' --force')
      cmd3 = "hashcat -m 16800 --show pass"
      output3 = subprocess.check_output(cmd3, shell=True)
      window8.destroy()
      Result = Label(root, text = 'Here is the result for password cracking:', fg="blue")
      Result.pack()
      success3.destroy()
      Start3.destroy()
      Textbox = Tkinter.Text(root, height=6, width=40)
      Textbox.pack()
      Textbox.insert(INSERT, output3)
      Report2 = Tkinter.Button(root, text ="Report & Exit", command=report2)
      Report2.place(x=120, y=135)
   else:
      Retype = Label(window8, text = 'Wrong file format', fg="red")
      Retype.grid(row=1, column=0, padx=2, pady=5, sticky=S)

# Generate report base on output (HC 16800)
def report2():
   global output3
   
   f = open('HC16800report.txt', 'w')
   output3 = output3.replace('\n', ' ')
   output3 = output3.replace('*', ' ')
   output3 = output3.replace(':', ' ')
   output3 = output3.split()

   for x in range(len(output3)):
      if x % 5 == 0:
         f.write('Hash: ' + output3[x] + '\n')
      if x % 5 == 1:
         f.write('AP MAC address: ' + output3[x] + '\n')
      if x % 5 == 2:
         f.write('Client MAC address: ' + output3[x] + '\n')
      if x % 5 == 4:
         f.write('Password: ' + output3[x] + '\n\n')
   CrackTime = str(datetime.datetime.now())
   f.write('Time: ' + CrackTime)

   window9 = Tkinter.Toplevel(root)
   window9.geometry("200x120")
   
   def convertToCsv():
      read_file = pd.read_csv(r'/root/Desktop/HC16800report.txt')
      read_file.to_csv (r'/root/Desktop/HC16800report.csv', index = None)
      os.system('rm HC16800report.txt')

   ConvertCSV = Tkinter.Button(window9, text ="Convert Text to CSV", command=convertToCsv, height = 1, width = 17)
   ConvertCSV.place(x=18, y=25)

   def exit2():
      root.destroy()

   Exit2 = Tkinter.Button(window9, text ="Exit Application", height = 1, width = 17, command=exit2)
   Exit2.place(x=18, y=70)

# root structure
Heading = Label(root, text = 'Choose a Password Cracking Tools', fg="blue")
Heading.pack()

JTR = Tkinter.Button(root, text ="JTR", command=John)
JTR.place(x=30, y=30)

Hashcat = Tkinter.Button(root, text ="HC 2500", command=hashcat)
Hashcat.place(x=115, y=30)

HC16800 = Tkinter.Button(root, text ="HC 16800", command=hc16800)
HC16800.place(x=220, y=30)

SubHeading = Label(root, text = 'Or Create a Wordlist First', fg="blue")
SubHeading.place(x=60, y=70)

Crunch = Tkinter.Button(root, text ="Crunch", command=Crunch)
Crunch.place(x=30, y=105)

Change1 = Tkinter.Button(root, text ="Change1", command=Change1)
Change1.place(x=130, y=105)

Filter = Tkinter.Button(root, text ="Filter", command=FilterPass)
Filter.place(x=245, y=105)

root.mainloop()
