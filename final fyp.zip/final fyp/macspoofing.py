
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule
import apless
import csv

import pandas as pd
from threading import Timer
global target
open1=open("/root/Documents/data/selected.txt","r+")
open1=open1.read()
open1split=open1.split("\n")
for line in open1split:
    if "wlan" in line:
        target=line[0:6]       
def scanningstart():
    os.system("rm mac-01.csv")
    b='airmon-ng check kill all'
    os.system(b)
    print("done airmon-ng check kill all")
    start='sudo airmon-ng start '+target
    os.system(start)
    macspoof=open("macspooftxt.txt","r")
    read=macspoof.read()
    macsppfgo=read.split("\n")
    macspoofrun=macsppfgo[0]
    
    p=subprocess.Popen(macspoofrun,shell=True )
    time.sleep(7)
    os.system("killall airodump-ng")
    time.sleep(1)
    os.system("sed -i 1d mac-01.csv")
    with open('mac-01.csv') as f:
            reader = pd.read_csv(f)
            
            p=reader.drop([' First time seen',' Last time seen',' Cipher',' Power',' # IV',' LAN IP',' ID-length',' Key'],axis=1)
            print(p)
            write=open("macadd.txt","w+")
            write.write(str(p))
            write.close()   
    def aaaaaa():
        try:
                open1=open("macadd.txt","rb")
                read= open1.read()
                sc_list=read.decode().split("Station MAC    Power   # packets               BSSID             NaN         NaN        NaN")
                
                sc_list1=sc_list[1]
                sc_list2=sc_list1.split("\n")
                write=open("macbom.txt","w+")
                for n in sc_list2:
                    
                    format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}')
                    a=str(n)
                    print("-------------------------------:"+a)
                    if re.findall(format1,a):
                        
                        write.write(str(a))
                        write.write("\n")
                write.close()
        except IndexError as e:
            print("no device")
            write=open("macbom.txt","w+")
            
    aaaaaa()
scanningstart()
