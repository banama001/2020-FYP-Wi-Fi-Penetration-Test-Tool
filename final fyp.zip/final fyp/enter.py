
import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule



def enter():
                        en="hostapd-wpe /etc/hostapd-wpe/hostapd-wpe.conf"
                        saveapless_txt=open("enter.txt",'w+')
                        p = subprocess.Popen(en,shell=True ,stdout=saveapless_txt, stderr=subprocess.STDOUT, preexec_fn=os.setsid)

                        global aploop_num
                        aploop_num=0
                        global aplesslist
                        aplesslist=[]

                        
                        while aploop_num==0:
                            shutil.copyfile('enter.txt','enterout.txt')
                            aplessout=open("enterout.txt",'r')
                            for n in aplessout:
                                print( n)
                                if ' response:' in n:
                                    print ('success')
                                    aplessfalagopen=open("enterflag.txt","w+")
                                    aplessfalagopen.write("aaa")
                                    aplessfalagopen.close()
                                    aploop_num=aploop_num+10
                                    aa=os.system("ps -C hostapd-wpe > enteroutput.txt")
                                    zz=open("enteroutput.txt","r")
                                    enterread=zz.read()
                                    enterread1=enterread.split("\n")
                                    enterread2=enterread1[1].split("  ")
                                    enterread3=enterread2[1].split(" ")
                                    os.system("kill -2 "+enterread3[0])
                                    
                                if "UNINITIALIZED->DISABLED" in n:
                                    aa=os.system("ps -C hostapd-wpe > enteroutput.txt")
                                    zz=open("enteroutput.txt","r")
                                    enterread=zz.read()
                                    enterread1=enterread.split("\n")
                                    #enterread2=enterread1[1].split("  ")
                                    #enterread3=enterread2[1].split(" ")
                                    #print(enterread3[0])
                                    stre=str(enterread1[1])
                                    streend=stre.find('?')
                                    enterread2=stre[0:streend]
                                    print(enterread2)
                                    a=os.system("kill -2 "+enterread2)
                                    print(a)
                                    aploop_num=1
                                    enter()
                                    
                            
                          #the real code does filtering here
     

enter()
