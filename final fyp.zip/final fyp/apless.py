
#======================
# imports
#======================

import signal
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import threading
import wifiadpater as fypad
import scannningnetwork as sca
import shlex
import time
import configparser
import signal
import threading
import multiprocessing as mp 
import os, subprocess
import shutil
#from PIL import Image, ImageTk
from PIL import Image
from PIL import ImageTk
from itertools import count 
from tkinter.filedialog import askopenfilename
import gif
from tkinter import *
from tkinter.ttk import *
import schedule 

global listcheck
listcheck=[]


def makeaplesslist():
        #aplesslist=open('viewtreeapless.txt',"r+")
        
        viewtreeaplesscompare=open('connecttopdelink.txt',"r")
        apread= viewtreeaplesscompare.read()
        aplist1=apread.split("\n")

        aplesslist1=open('viewtreeapless.txt',"r")
        apreadorg= aplesslist1.read()  
        aplist2=apreadorg.split("\n")
        for n in aplist1:
            
            addaplesslist=open('viewtreeapless.txt',"a+")
            
            global addapp
            addapp=0
            
            bssid=n[4:22]
            essid=n[93:]
            
            
            for ana in aplist2:
                
                if bssid in ana:
                        if essid in ana:
                                print('same aplesslist not added')
                                addapp=1        
                        else:
                            
                            ESSID=ana[93:]
                            os.system("sed -i '/"+ana+"/d' /root/Documents/gui/viewtreeapless.txt")
                            addapp==0
                else:
                        addapp==0
                        
                        
            
            if addapp==0:
                        
                
                        print("added the new record of apless")
                        addaplesslist.write(n)
                        addaplesslist.write("\n")
                        addaplesslist.close()
                        
            
            
          
        

