
import sys
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import toolTip
import wifiadpater as fypad
import subprocess
import os
import subprocess
from tkinter import messagebox

def dec_but():
    iwconfig="iwconfig > /root/Documents/data/iwconfig.txt"
    os.system(iwconfig)
    a="airmon-ng > /root/Documents/data/wifiadpater.txt"
    os.system(a)
    
    
        


def dec():
    
    a="iwconfig > /root/Documents/data/iwconfig.txt"
    out = os.system(a)
    print(out)
    open1=open("/root/Documents/data/iwconfig.txt","r+")
    read= open1.read()
    iwconfigtxt=read.split("\n")

    list_wlan=[]
    for line in iwconfigtxt:
        print ("line:"+line)
        if "wlan" in line:
            wlantarget=line[0:8]
            list_wlan.append(wlantarget)
            print("added")
            print(list_wlan)
        

    
    if list_wlan == []:
        Tk().withdraw()
        messagebox.showerror(title = "Error", message = 'CAN NOT FIND WLAN')
        sys.exit()
        
    else:
        for a in list_wlan:
            if 'mon' in str(a):
                print("mon:"+str(a))
                airmonng="airmon-ng stop " + a
                subprocess.Popen(airmonng, shell=True,bufsize=60,stdout=subprocess.PIPE, stderr=subprocess.STDOUT,close_fds=True)
            
                dec()

            
            
            else:
            
                dec_but()

dec()
