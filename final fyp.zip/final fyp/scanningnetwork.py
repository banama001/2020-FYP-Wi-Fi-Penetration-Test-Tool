
import time
import sys
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import Menu
from tkinter import Spinbox
from tkinter import messagebox as mBox
import toolTip

import subprocess
import os
import subprocess
from tkinter import messagebox
import csv

import pandas as pd

global target
open1=open("/root/Documents/data/selected.txt","r+")
open1=open1.read()
open1split=open1.split("\n")
for line in open1split:
    if "wlan" in line:
        target=line[0:6]
        print("scanning")
        print(target)


def getall():
    def scanningstart():
        os.system("rm sck-01.csv")
        b='airmon-ng check kill all'
        os.system(b)
        print("done airmon-ng check kill all")   
        start='sudo airmon-ng start '+target
        os.system(start)
        print(start)
        #os.system("killall -e airodump-ng")
        airmonngstart='sudo airodump-ng  -w sck --output-format csv '+target+"mon "
        print(airmonngstart)
        #p=subprocess.Popen(airmonngstart,shell=True ,stdout=subprocess.PIPE ,stderr=subprocess.STDOUT, preexec_fn=os.setsid)
        p=subprocess.Popen(airmonngstart,shell=True )
        time.sleep(6)
        
        
        os.system("killall airodump-ng")
        time.sleep(1)

    
    







#-----------------有連接driver既network----------------------#

    def maketable():
        os.system("sed -i 1d sck-01.csv")
        with open('sck-01.csv') as f:
            reader = pd.read_csv(f)
            print(reader)
            p=reader.drop([' First time seen',' Last time seen',' Cipher',' Power',' # IV',' LAN IP',' ID-length',' Key'],axis=1)
            print(p)
            write=open("testing.txt","w+")
            write.write(str(p))
            write.close()
            
        
           
       
    def aaaa():
        try:
                open1=open("testing.txt","rb")
                read= open1.read()
                sc_list=read.decode().split("Station MAC    Power   # packets               BSSID ")
                sc_list1=sc_list[1]
                sc_list2=sc_list1.split("\n")
                write=open("connectbomdelink.txt","w+")
                for n in sc_list2:
                    
                    format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}')
                    a=str(n)
                    
                    if re.findall(format1,a):
                        
                        write.write(str(a))
                        write.write("\n")
                write.close()
        except IndexError:
                getall()
                


    def bbbb():
                open1=open("testing.txt","rb")
                read= open1.read()
                sc_list=read.decode().split("Station MAC    Power   # packets               BSSID ")
                sc_list1=sc_list[0]
                sc_list2=sc_list1.split("\n")
                write1=open("connecttopdelink.txt", "w+") 
                for n in sc_list2:
                    
                    format1=re.compile('\w{2}:\w{2}:\w{2}:\w{2}')
                    a=str(n)
                        
                    if re.findall(format1,a):
                            print("2")
                            print(str(a))
                            write1.write(str(a))
                            write1.write("\n")
                write1.close()

    def mix():
        print("mix")
        match=open("connecttopdelink.txt","r")
        read= match.read()
        list1=read.split("\n")
        
        open1=open("connectbomdelink.txt","r")
        write=open("connectmatch.txt","w+")
        read1= open1.read()
        list2=read1.split("\n")
        for a in list1:
            top=a[4:21]
            print(top)
            for n in list2:
                bom=n[45:62]
                print(bom)
                
                if str(top) ==str(bom):
                    print("success")
                    print(a)
                    write.write(str(a))
                    write.write("\n")
        write.close()
        
                                  



                     
    def all():
            scanningstart()
            maketable()
            aaaa()
            bbbb()
            mix()
    all()

   


